# WebGL contour benchmark

- Scalar texture: **1799 × 1059**
- Viewport: **1024 × 768**
- Boundaries/bands: **17 / 16**
- Driver: `WebGL 2.0 (OpenGL ES 3.0 Chromium)` / `WebKit WebGL`
- Method: 7 rounds × 12 frames; median GPU timer-query time

| Renderer | Median ms/frame | Relative |
|---|---:|---:|
| Current-shape GPU fill baseline | 27.293 | 1.00× |
| Exact GPU fill | 22.841 | 1.19× throughput |
| Favorable legacy GPU-only fill + analytic lines | 41.965 | 1.00× |
| Exact split fill + lines | 54.159 | 0.77× throughput |
| Exact fused fill + lines | 36.517 | 1.15× throughput |

This is a **SwiftShader microbenchmark**, not a physical-GPU result. The favorable legacy line baseline excludes the current worker/WASM topology, coordinate transformation, JavaScript object construction, and polyline upload costs; it is intentionally harder for the fused path to beat. Run `python3 bench/webgl_benchmark.py` on each target GPU before publishing hardware-specific claims.
