#!/usr/bin/env python3
"""Reproducible WebGL2 contour benchmark in Chromium.

This measures completed frame cost (gl.finish) for an HRRR-sized scalar texture.
It deliberately includes a favorable analytic two-pass baseline for the old
architecture; AutumnPlot's current vector-contour worker/path construction is
not included, so the baseline understates the legacy total cost.
"""
from __future__ import annotations

import json
import os
import shutil
import statistics
import subprocess
import tempfile
import time
import urllib.request
from pathlib import Path

import websocket

ROOT = Path(__file__).resolve().parents[1]
PORT = 19228
DISPLAY = ':97'


def inject_after_version(source: str, code: str) -> str:
    first, rest = source.split('\n', 1)
    return f"{first}\n{code}\n{rest}"


def evaluate(ws: websocket.WebSocket, expression: str, request_id: int = 1) -> object:
    ws.send(json.dumps({
        'id': request_id,
        'method': 'Runtime.evaluate',
        'params': {
            'expression': expression,
            'returnByValue': True,
            'awaitPromise': True,
            'timeout': 120_000,
        },
    }))
    while True:
        message = json.loads(ws.recv())
        if message.get('id') != request_id:
            continue
        result = message.get('result', {})
        if 'exceptionDetails' in result:
            raise RuntimeError(json.dumps(result['exceptionDetails'], indent=2))
        return result['result'].get('value')


def main() -> None:
    chromium_path = next(
        (shutil.which(name) for name in ('chromium', 'chromium-browser', 'google-chrome') if shutil.which(name)),
        None,
    )
    xvfb_path = shutil.which('Xvfb')
    if chromium_path is None or xvfb_path is None:
        raise RuntimeError('Chromium and Xvfb are required')

    sampler = (
        'uniform sampler2D u_field;\n'
        'highp float get_field_value(highp vec2 p) { return texture(u_field, p).r; }'
    )
    fill_source = inject_after_version(
        (ROOT / 'autumnplot-src/glsl/weather_contours_fragment.glsl').read_text(),
        '#define REGULAR_LEVELS\n' + sampler,
    )
    fused_source = inject_after_version(
        (ROOT / 'autumnplot-src/glsl/weather_contours_fragment.glsl').read_text(),
        '#define REGULAR_LEVELS\n#define CONTOUR_LINES\n' + sampler,
    )
    line_source = inject_after_version(
        (ROOT / 'autumnplot-src/glsl/weather_contour_lines_fragment.glsl').read_text(),
        '#define REGULAR_LEVELS\n' + sampler,
    )

    vertex_source = '''#version 300 es
    in vec2 a_pos;
    in vec2 a_tex_coord;
    out highp vec2 v_tex_coord;
    void main() { gl_Position = vec4(a_pos, 0.0, 1.0); v_tex_coord = a_tex_coord; }
    '''

    # This mirrors the current upstream ContourFill shape: scalar lookup,
    # nonlinear index texture lookup, then palette texture lookup.
    legacy_fill_source = '''#version 300 es
    in highp vec2 v_tex_coord;
    out highp vec4 fragColor;
    uniform sampler2D u_field;
    uniform sampler2D u_cmap_sampler;
    uniform sampler2D u_cmap_nonlin_sampler;
    uniform highp float u_cmap_min;
    uniform highp float u_cmap_max;
    uniform highp vec4 u_underflow_color;
    uniform highp vec4 u_overflow_color;
    uniform int u_n_index;
    uniform highp float u_opacity;
    lowp vec4 apply_colormap(highp float value) {
        lowp float normed_val = (value - u_cmap_min) / (u_cmap_max - u_cmap_min);
        if (normed_val < 0.0) return u_underflow_color;
        if (normed_val > 1.0) return u_overflow_color;
        lowp float buffer = 1.0 / (2.0 * float(u_n_index));
        normed_val = buffer + normed_val * (1.0 - 2.0 * buffer);
        highp float nonlinear = texture(u_cmap_nonlin_sampler, vec2(normed_val, 0.5)).r;
        return texture(u_cmap_sampler, vec2(nonlinear, 0.5));
    }
    void main() {
        highp float value = texture(u_field, v_tex_coord).r;
        if (isnan(value) || isinf(value)) discard;
        fragColor = apply_colormap(value);
        fragColor.a *= u_opacity;
    }
    '''

    # A deliberately favorable GPU-only line baseline. The real old Contour
    # path additionally pays worker/WASM, topology, projection and polyline costs.
    legacy_line_source = '''#version 300 es
    in highp vec2 v_tex_coord;
    out highp vec4 fragColor;
    uniform sampler2D u_field;
    uniform highp float u_min;
    uniform highp float u_interval;
    uniform highp float u_width;
    void main() {
        highp float value = texture(u_field, v_tex_coord).r;
        highp float rank = (value - u_min) / u_interval;
        highp float nearest = floor(rank + 0.5);
        highp float gradient = max(fwidth(value), 1.0e-12);
        highp float distance_px = abs(value - (u_min + nearest * u_interval)) / gradient;
        highp float alpha = 1.0 - smoothstep(0.5 * u_width - 0.75, 0.5 * u_width + 0.75, distance_px);
        if (!(alpha > 0.0)) discard;
        fragColor = vec4(vec3(0.08) * alpha, alpha);
    }
    '''

    payload = {
        'vertex': vertex_source,
        'exactFill': fill_source,
        'exactFused': fused_source,
        'exactLine': line_source,
        'legacyFill': legacy_fill_source,
        'legacyLine': legacy_line_source,
    }

    expression = f'''(async () => {{
      const src = {json.dumps(payload)};
      const FIELD_W = 1799, FIELD_H = 1059;
      const VIEW_W = 1024, VIEW_H = 768;
      const LEVEL_COUNT = 17, BAND_COUNT = 16;
      const canvas = document.createElement('canvas');
      canvas.width = VIEW_W; canvas.height = VIEW_H;
      const gl = canvas.getContext('webgl2', {{alpha: true, antialias: false, depth: false, stencil: false}});
      if (!gl) throw new Error('WebGL2 unavailable');
      gl.viewport(0, 0, VIEW_W, VIEW_H);

      function shader(type, source, name) {{
        const s = gl.createShader(type); gl.shaderSource(s, source); gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(name + ': ' + gl.getShaderInfoLog(s));
        return s;
      }}
      function program(fragment, name) {{
        const p = gl.createProgram();
        gl.attachShader(p, shader(gl.VERTEX_SHADER, src.vertex, name + '/vs'));
        gl.attachShader(p, shader(gl.FRAGMENT_SHADER, fragment, name + '/fs'));
        gl.linkProgram(p);
        if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(name + ': ' + gl.getProgramInfoLog(p));
        return p;
      }}
      const programs = {{
        legacyFill: program(src.legacyFill, 'legacyFill'),
        legacyLine: program(src.legacyLine, 'legacyLine'),
        exactFill: program(src.exactFill, 'exactFill'),
        exactFused: program(src.exactFused, 'exactFused'),
        exactLine: program(src.exactLine, 'exactLine'),
      }};

      const positions = new Float32Array([-1,-1, 3,-1, -1,3]);
      const texcoords = new Float32Array([0,0, 2,0, 0,2]);
      function buffer(data) {{
        const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW); return b;
      }}
      const posBuffer = buffer(positions), texBuffer = buffer(texcoords);
      function bindGeometry(p) {{
        let loc = gl.getAttribLocation(p, 'a_pos'); gl.bindBuffer(gl.ARRAY_BUFFER, posBuffer); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
        loc = gl.getAttribLocation(p, 'a_tex_coord'); gl.bindBuffer(gl.ARRAY_BUFFER, texBuffer); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
      }}
      function texture2d(internalFormat, width, height, format, type, data, filter) {{
        const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
        gl.texImage2D(gl.TEXTURE_2D, 0, internalFormat, width, height, 0, format, type, data);
        return t;
      }}

      const field = new Float32Array(FIELD_W * FIELD_H);
      for (let y = 0; y < FIELD_H; ++y) {{
        const fy = y / (FIELD_H - 1);
        for (let x = 0; x < FIELD_W; ++x) {{
          const fx = x / (FIELD_W - 1);
          field[x + y * FIELD_W] = 8.0 + 5.2 * Math.sin(fx * 20.0 + fy * 2.0) * Math.cos(fy * 13.0) + 3.2 * (fx - fy);
        }}
      }}
      const fieldTex = texture2d(gl.R32F, FIELD_W, FIELD_H, gl.RED, gl.FLOAT, field, gl.LINEAR);

      const palette = new Uint8Array((BAND_COUNT + 2) * 4);
      for (let i = 0; i < BAND_COUNT + 2; ++i) {{
        const q = i / (BAND_COUNT + 1);
        palette[4*i] = Math.round(255 * Math.min(1, 1.7*q));
        palette[4*i+1] = Math.round(255 * (1.0 - Math.abs(q - 0.5) * 1.8));
        palette[4*i+2] = Math.round(255 * Math.min(1, 1.7*(1-q)));
        palette[4*i+3] = 230;
      }}
      const exactPalette = texture2d(gl.RGBA8, BAND_COUNT + 2, 1, gl.RGBA, gl.UNSIGNED_BYTE, palette, gl.NEAREST);
      const legacyPaletteData = palette.slice(4, 4 * (BAND_COUNT + 1));
      const legacyPalette = texture2d(gl.RGBA8, BAND_COUNT, 1, gl.RGBA, gl.UNSIGNED_BYTE, legacyPaletteData, gl.NEAREST);
      const inverse = new Float32Array(101); for (let i=0;i<101;++i) inverse[i] = i/100;
      const inverseTex = texture2d(gl.R32F, 101, 1, gl.RED, gl.FLOAT, inverse, gl.LINEAR);

      function uniform(p, name) {{ const loc = gl.getUniformLocation(p, name); if (loc === null) throw new Error('missing uniform '+name); return loc; }}
      function useTexture(p, name, unit, tex) {{ gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, tex); gl.uniform1i(uniform(p,name), unit); }}
      function commonExact(p, fill) {{
        gl.useProgram(p); bindGeometry(p); useTexture(p, 'u_field', 0, fieldTex);
        gl.uniform1i(uniform(p,'u_level_count'), LEVEL_COUNT);
        gl.uniform1i(uniform(p,'u_band_count'), BAND_COUNT);
        gl.uniform1f(uniform(p,'u_level_min'), 0.0);
        gl.uniform1f(uniform(p,'u_level_max'), 16.0);
        gl.uniform1f(uniform(p,'u_level_interval'), 1.0);
        if (fill) {{ useTexture(p, 'u_band_palette', 1, exactPalette); gl.uniform1f(uniform(p,'u_fill_opacity'), 0.82); }}
      }}
      function lineUniforms(p) {{
        gl.uniform4f(uniform(p,'u_line_color'), .08,.08,.08,1);
        gl.uniform1f(uniform(p,'u_line_width'), 1.15);
        gl.uniform1f(uniform(p,'u_line_opacity'), .9);
        gl.uniform1i(uniform(p,'u_major_every'), 4);
        gl.uniform1i(uniform(p,'u_major_offset'), 0);
        gl.uniform4f(uniform(p,'u_major_line_color'), 0,0,0,1);
        gl.uniform1f(uniform(p,'u_major_line_width'), 2.1);
        gl.uniform1f(uniform(p,'u_line_feather'), .72);
      }}
      function draw(p) {{ gl.useProgram(p); gl.drawArrays(gl.TRIANGLES, 0, 3); }}
      function clear() {{ gl.disable(gl.SCISSOR_TEST); gl.clearColor(.1,.12,.15,1); gl.clear(gl.COLOR_BUFFER_BIT); }}
      function straightBlend() {{ gl.enable(gl.BLEND); gl.blendFuncSeparate(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA); }}
      function premulBlend() {{ gl.enable(gl.BLEND); gl.blendFuncSeparate(gl.ONE, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA); }}

      // Initialize all program state once; the measured path changes only normal render state.
      {{ const p=programs.legacyFill; gl.useProgram(p); bindGeometry(p); useTexture(p,'u_field',0,fieldTex); useTexture(p,'u_cmap_sampler',3,legacyPalette); useTexture(p,'u_cmap_nonlin_sampler',4,inverseTex); gl.uniform1f(uniform(p,'u_cmap_min'),0); gl.uniform1f(uniform(p,'u_cmap_max'),16); gl.uniform4f(uniform(p,'u_underflow_color'),0,0,0,0); gl.uniform4f(uniform(p,'u_overflow_color'),0,0,0,0); gl.uniform1i(uniform(p,'u_n_index'),101); gl.uniform1f(uniform(p,'u_opacity'),.82); }}
      {{ const p=programs.legacyLine; gl.useProgram(p); bindGeometry(p); useTexture(p,'u_field',0,fieldTex); gl.uniform1f(uniform(p,'u_min'),0); gl.uniform1f(uniform(p,'u_interval'),1); gl.uniform1f(uniform(p,'u_width'),1.3); }}
      commonExact(programs.exactFill, true);
      commonExact(programs.exactFused, true); lineUniforms(programs.exactFused);
      commonExact(programs.exactLine, false); lineUniforms(programs.exactLine);

      const renderers = {{
        legacy_fill_only() {{ clear(); straightBlend(); draw(programs.legacyFill); }},
        exact_fill_only() {{ clear(); straightBlend(); draw(programs.exactFill); }},
        favorable_legacy_two_pass_fill_lines() {{ clear(); straightBlend(); draw(programs.legacyFill); premulBlend(); draw(programs.legacyLine); }},
        exact_split_fill_lines() {{ clear(); straightBlend(); draw(programs.exactFill); premulBlend(); draw(programs.exactLine); }},
        exact_fused_fill_lines() {{ clear(); premulBlend(); draw(programs.exactFused); }},
      }};
      const names = Object.keys(renderers);
      for (const name of names) {{ for (let i=0;i<8;++i) renderers[name](); gl.finish(); }}
      const timer = gl.getExtension('EXT_disjoint_timer_query_webgl2');
      const samples = Object.fromEntries(names.map(n => [n, []]));
      const rounds = 7, frames = 12;
      async function timed(name) {{
        if (timer) {{
          const query = gl.createQuery();
          gl.beginQuery(timer.TIME_ELAPSED_EXT, query);
          for (let i=0;i<frames;++i) renderers[name]();
          gl.endQuery(timer.TIME_ELAPSED_EXT);
          gl.flush();
          const deadline = performance.now() + 30000;
          while (!gl.getQueryParameter(query, gl.QUERY_RESULT_AVAILABLE)) {{
            if (performance.now() > deadline) throw new Error('timer query timeout: ' + name);
            await new Promise(resolve => setTimeout(resolve, 0));
          }}
          if (gl.getParameter(timer.GPU_DISJOINT_EXT)) throw new Error('disjoint timer query');
          const nanoseconds = gl.getQueryParameter(query, gl.QUERY_RESULT);
          gl.deleteQuery(query);
          return nanoseconds / 1.0e6 / frames;
        }}
        const pixelProbe = new Uint8Array(4);
        const start = performance.now();
        for (let i=0;i<frames;++i) renderers[name]();
        gl.readPixels(517,389,1,1,gl.RGBA,gl.UNSIGNED_BYTE,pixelProbe);
        return (performance.now() - start) / frames;
      }}
      for (let round=0; round<rounds; ++round) {{
        const shift = round % names.length;
        const order = names.slice(shift).concat(names.slice(0, shift));
        for (const name of order) samples[name].push(await timed(name));
      }}
      const pixel = new Uint8Array(4); gl.readPixels(517,389,1,1,gl.RGBA,gl.UNSIGNED_BYTE,pixel);
      function median(values) {{ const v=values.slice().sort((a,b)=>a-b); return v[Math.floor(v.length/2)]; }}
      const medians = Object.fromEntries(names.map(n => [n, median(samples[n])]));
      return {{
        field: [FIELD_W,FIELD_H], viewport:[VIEW_W,VIEW_H], boundaries:LEVEL_COUNT, bands:BAND_COUNT,
        rounds, frames_per_round:frames, medians_ms:medians, samples_ms:samples,
        renderer: gl.getParameter(gl.RENDERER), version:gl.getParameter(gl.VERSION), timer_query: !!timer, pixel:Array.from(pixel),
      }};
    }})()'''

    xvfb = chromium = None
    profile: str | None = None
    try:
        xvfb = subprocess.Popen([xvfb_path, DISPLAY, '-screen', '0', '1280x800x24'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(0.4)
        profile = tempfile.mkdtemp(prefix='weather-contours-bench-')
        env = os.environ.copy(); env['DISPLAY'] = DISPLAY
        chromium = subprocess.Popen([
            chromium_path, '--no-sandbox', '--disable-dev-shm-usage', '--use-angle=swiftshader',
            '--enable-unsafe-swiftshader', f'--remote-debugging-port={PORT}', '--remote-allow-origins=*',
            f'--user-data-dir={profile}', 'about:blank',
        ], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        tabs = None
        for _ in range(120):
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{PORT}/json', timeout=0.2) as response:
                    tabs = json.load(response)
                if tabs: break
            except Exception:
                pass
            time.sleep(0.1)
        if not tabs: raise RuntimeError('Chromium DevTools endpoint did not start')
        tab = next(tab for tab in tabs if tab.get('type') == 'page')
        ws = websocket.create_connection(tab['webSocketDebuggerUrl'], timeout=130, origin=f'http://127.0.0.1:{PORT}')
        try: result = evaluate(ws, expression)
        finally: ws.close()
        if not isinstance(result, dict): raise RuntimeError(f'unexpected result: {result!r}')

        out_dir = ROOT / 'bench'
        (out_dir / 'webgl-results.json').write_text(json.dumps(result, indent=2) + '\n')
        med = result['medians_ms']
        legacy_fill = med['legacy_fill_only']
        legacy_two = med['favorable_legacy_two_pass_fill_lines']
        markdown = f'''# WebGL contour benchmark\n\n- Scalar texture: **{result['field'][0]} × {result['field'][1]}**\n- Viewport: **{result['viewport'][0]} × {result['viewport'][1]}**\n- Boundaries/bands: **{result['boundaries']} / {result['bands']}**\n- Driver: `{result['version']}` / `{result['renderer']}`\n- Method: {result['rounds']} rounds × {result['frames_per_round']} frames; median {'GPU timer-query time' if result.get('timer_query') else 'readback-synchronized wall time'}\n\n| Renderer | Median ms/frame | Relative |\n|---|---:|---:|\n| Current-shape GPU fill baseline | {legacy_fill:.3f} | 1.00× |\n| Exact GPU fill | {med['exact_fill_only']:.3f} | {legacy_fill / med['exact_fill_only']:.2f}× throughput |\n| Favorable legacy GPU-only fill + analytic lines | {legacy_two:.3f} | 1.00× |\n| Exact split fill + lines | {med['exact_split_fill_lines']:.3f} | {legacy_two / med['exact_split_fill_lines']:.2f}× throughput |\n| Exact fused fill + lines | {med['exact_fused_fill_lines']:.3f} | {legacy_two / med['exact_fused_fill_lines']:.2f}× throughput |\n\nThis is a **SwiftShader microbenchmark**, not a physical-GPU result. The favorable legacy line baseline excludes the current worker/WASM topology, coordinate transformation, JavaScript object construction, and polyline upload costs; it is intentionally harder for the fused path to beat. Run `python3 bench/webgl_benchmark.py` on each target GPU before publishing hardware-specific claims.\n'''
        (out_dir / 'RESULTS.md').write_text(markdown)
        print(markdown)
    finally:
        for process in (chromium, xvfb):
            if process is not None and process.poll() is None: process.terminate()
        time.sleep(0.2)
        for process in (chromium, xvfb):
            if process is not None and process.poll() is None: process.kill()
        if profile is not None: shutil.rmtree(profile, ignore_errors=True)


if __name__ == '__main__':
    main()
