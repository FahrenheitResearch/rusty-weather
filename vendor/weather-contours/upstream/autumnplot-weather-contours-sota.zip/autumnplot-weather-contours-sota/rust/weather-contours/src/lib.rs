//! Structured-grid weather contour geometry.
//!
//! The crate contains two output-sensitive engines:
//! - OIRT (Ordinal Iso-Rail Traversal) for connected isolines;
//! - COBRM (Critical Ordinal Band-Rail Mesh) for watertight filled isobands.
//!
//! OIRT is specialized for weather grids and sorted isoline levels:
//! - each grid edge stores the contiguous ordinal range of levels it crosses;
//! - a prefix sum gives every `(edge, level)` crossing an exact integer ID;
//! - cells connect IDs directly into a degree-two graph;
//! - degree-one chains are emitted first, then remaining cycles.
//!
//! This removes floating-point endpoint hashes, per-segment heap objects, and
//! repeated front/back vector splicing from the contour hot path.

#![deny(unsafe_op_in_unsafe_fn)]

use std::error::Error;
use std::fmt::{Display, Formatter};

mod bands;
pub use bands::*;

#[cfg(target_arch = "wasm32")]
mod wasm_abi;

const INVALID_NODE: u32 = u32::MAX;
pub const CLOSED_PATH_FLAG: u8 = 1;

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct ContourStats {
    pub grid_points: usize,
    pub cells_total: usize,
    pub cells_finite: usize,
    pub cells_skipped_non_finite: usize,
    pub level_count: usize,
    pub edge_crossings: usize,
    pub connected_crossings: usize,
    pub segment_count: usize,
    pub open_path_count: usize,
    pub closed_path_count: usize,
}

/// Packed contours. `vertices` is flat x/y pairs. `path_offsets` is measured
/// in points, not floats. Closed paths do not duplicate their first point.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct PackedContours {
    pub levels: Vec<f32>,
    pub vertices: Vec<f32>,
    pub path_offsets: Vec<u32>,
    pub path_level_indices: Vec<u32>,
    pub path_flags: Vec<u8>,
    pub stats: ContourStats,
}

impl PackedContours {
    pub fn point_count(&self) -> usize {
        self.vertices.len() / 2
    }

    pub fn path_count(&self) -> usize {
        self.path_level_indices.len()
    }

    pub fn path_is_closed(&self, path: usize) -> bool {
        self.path_flags
            .get(path)
            .map(|flags| flags & CLOSED_PATH_FLAG != 0)
            .unwrap_or(false)
    }

    pub fn validate(&self) -> Result<(), ContourError> {
        if self.vertices.len() % 2 != 0 {
            return Err(ContourError::Invariant("vertices are not x/y pairs"));
        }
        if self.path_offsets.len() != self.path_count() + 1 {
            return Err(ContourError::Invariant(
                "path_offsets length is not path_count + 1",
            ));
        }
        if self.path_flags.len() != self.path_count() {
            return Err(ContourError::Invariant(
                "path_flags length does not match path count",
            ));
        }
        if self.path_offsets.first().copied().unwrap_or(0) != 0 {
            return Err(ContourError::Invariant("path offsets do not start at zero"));
        }
        if self.path_offsets.last().copied().unwrap_or(0) as usize != self.point_count() {
            return Err(ContourError::Invariant(
                "last path offset does not equal point count",
            ));
        }
        for offsets in self.path_offsets.windows(2) {
            if offsets[1] < offsets[0] || offsets[1] - offsets[0] < 2 {
                return Err(ContourError::Invariant(
                    "path offsets are non-monotonic or describe a path shorter than two points",
                ));
            }
        }
        if self
            .path_level_indices
            .iter()
            .any(|&level| level as usize >= self.levels.len())
        {
            return Err(ContourError::Invariant("path references a missing level"));
        }
        Ok(())
    }
}

#[derive(Clone, Debug, PartialEq)]
pub enum ContourError {
    GridTooSmall { nx: usize, ny: usize },
    DataLength { expected: usize, actual: usize },
    XLength { expected: usize, actual: usize },
    YLength { expected: usize, actual: usize },
    NonFiniteX(usize),
    NonFiniteY(usize),
    InvalidInterval(f32),
    InvalidAnchor(f32),
    TooManyLevels(usize),
    SizeOverflow,
    TooManyCrossings(u64),
    MissingCrossing { edge: usize, level: usize },
    LevelMismatch { node_a: u32, node_b: u32 },
    DegreeOverflow(u32),
    Invariant(&'static str),
}

impl Display for ContourError {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::GridTooSmall { nx, ny } => {
                write!(f, "grid must be at least 2 x 2, got {nx} x {ny}")
            }
            Self::DataLength { expected, actual } => {
                write!(f, "data length mismatch: expected {expected}, got {actual}")
            }
            Self::XLength { expected, actual } => {
                write!(f, "x-coordinate length mismatch: expected {expected}, got {actual}")
            }
            Self::YLength { expected, actual } => {
                write!(f, "y-coordinate length mismatch: expected {expected}, got {actual}")
            }
            Self::NonFiniteX(index) => write!(f, "x-coordinate {index} is non-finite"),
            Self::NonFiniteY(index) => write!(f, "y-coordinate {index} is non-finite"),
            Self::InvalidInterval(value) => {
                write!(f, "contour interval must be finite and positive, got {value}")
            }
            Self::InvalidAnchor(value) => write!(f, "contour anchor must be finite, got {value}"),
            Self::TooManyLevels(count) => write!(f, "too many contour levels: {count}"),
            Self::SizeOverflow => write!(f, "grid or output size overflow"),
            Self::TooManyCrossings(count) => {
                write!(f, "too many edge/level crossings for packed u32 IDs: {count}")
            }
            Self::MissingCrossing { edge, level } => {
                write!(f, "missing crossing for edge {edge}, level index {level}")
            }
            Self::LevelMismatch { node_a, node_b } => {
                write!(f, "attempted to connect nodes from different levels: {node_a}, {node_b}")
            }
            Self::DegreeOverflow(node) => write!(f, "contour node {node} exceeded degree two"),
            Self::Invariant(message) => write!(f, "internal contour invariant failed: {message}"),
        }
    }
}

impl Error for ContourError {}

#[derive(Clone, Copy, Debug, Default)]
struct EdgeRange {
    first: u32,
    count: u32,
    base: u32,
}

impl EdgeRange {
    fn node_for(self, level_index: usize) -> Option<u32> {
        let level = u32::try_from(level_index).ok()?;
        let end = self.first.checked_add(self.count)?;
        if level < self.first || level >= end {
            return None;
        }
        self.base.checked_add(level - self.first)
    }
}

#[derive(Clone, Copy)]
enum CellEdge {
    South = 0,
    East = 1,
    North = 2,
    West = 3,
}

pub fn normalize_levels(levels: &[f32]) -> Vec<f32> {
    let mut output: Vec<f32> = levels.iter().copied().filter(|value| value.is_finite()).collect();
    output.sort_by(f32::total_cmp);
    output.dedup_by(|a, b| *a == *b);
    output
}

/// Generate regular levels `anchor + n * interval` spanning finite data.
pub fn interval_levels(
    values: &[f32],
    interval: f32,
    anchor: f32,
) -> Result<Vec<f32>, ContourError> {
    if !interval.is_finite() || interval <= 0.0 {
        return Err(ContourError::InvalidInterval(interval));
    }
    if !anchor.is_finite() {
        return Err(ContourError::InvalidAnchor(anchor));
    }

    let mut minimum = f32::INFINITY;
    let mut maximum = f32::NEG_INFINITY;
    for value in values.iter().copied().filter(|value| value.is_finite()) {
        minimum = minimum.min(value);
        maximum = maximum.max(value);
    }
    if !minimum.is_finite() || !maximum.is_finite() {
        return Ok(Vec::new());
    }

    let step = interval as f64;
    let origin = anchor as f64;
    let first = (((minimum as f64) - origin) / step).ceil();
    let last = (((maximum as f64) - origin) / step).floor();
    if first > last {
        return Ok(Vec::new());
    }
    let count_f64 = last - first + 1.0;
    if !count_f64.is_finite() || count_f64 > u32::MAX as f64 {
        return Err(ContourError::TooManyLevels(count_f64.max(0.0) as usize));
    }

    let count = count_f64 as usize;
    let mut levels = Vec::with_capacity(count);
    for offset in 0..count {
        levels.push((origin + (first + offset as f64) * step) as f32);
    }
    Ok(normalize_levels(&levels))
}

pub fn contour_interval(
    values: &[f32],
    nx: usize,
    ny: usize,
    xs: &[f32],
    ys: &[f32],
    interval: f32,
    anchor: f32,
) -> Result<PackedContours, ContourError> {
    let levels = interval_levels(values, interval, anchor)?;
    contour_levels(values, nx, ny, xs, ys, &levels)
}

pub fn contour_levels(
    values: &[f32],
    nx: usize,
    ny: usize,
    xs: &[f32],
    ys: &[f32],
    requested_levels: &[f32],
) -> Result<PackedContours, ContourError> {
    validate_inputs(values, nx, ny, xs, ys)?;
    let levels = normalize_levels(requested_levels);
    if levels.len() > u32::MAX as usize {
        return Err(ContourError::TooManyLevels(levels.len()));
    }

    let horizontal_count = (nx - 1).checked_mul(ny).ok_or(ContourError::SizeOverflow)?;
    let vertical_count = nx.checked_mul(ny - 1).ok_or(ContourError::SizeOverflow)?;
    let edge_count = horizontal_count
        .checked_add(vertical_count)
        .ok_or(ContourError::SizeOverflow)?;
    let cells_total = (nx - 1)
        .checked_mul(ny - 1)
        .ok_or(ContourError::SizeOverflow)?;

    let mut stats = ContourStats {
        grid_points: values.len(),
        cells_total,
        level_count: levels.len(),
        ..ContourStats::default()
    };

    if levels.is_empty() {
        return Ok(PackedContours {
            levels,
            path_offsets: vec![0],
            stats,
            ..PackedContours::default()
        });
    }

    // Phase 1: ordinal ranges for horizontal and vertical grid edges.
    let mut ranges = vec![EdgeRange::default(); edge_count];
    for j in 0..ny {
        let data_row = j * nx;
        let edge_row = j * (nx - 1);
        for i in 0..(nx - 1) {
            ranges[edge_row + i] = crossing_range(
                values[data_row + i],
                values[data_row + i + 1],
                &levels,
            );
        }
    }
    for j in 0..(ny - 1) {
        let data_row = j * nx;
        let edge_row = horizontal_count + j * nx;
        for i in 0..nx {
            ranges[edge_row + i] = crossing_range(
                values[data_row + i],
                values[data_row + nx + i],
                &levels,
            );
        }
    }

    let mut crossing_count = 0_u64;
    for range in &mut ranges {
        if crossing_count > u32::MAX as u64 {
            return Err(ContourError::TooManyCrossings(crossing_count));
        }
        range.base = crossing_count as u32;
        crossing_count += range.count as u64;
    }
    if crossing_count > u32::MAX as u64 {
        return Err(ContourError::TooManyCrossings(crossing_count));
    }
    let node_count = usize::try_from(crossing_count).map_err(|_| ContourError::SizeOverflow)?;
    stats.edge_crossings = node_count;

    let mut node_x = vec![0.0_f32; node_count];
    let mut node_y = vec![0.0_f32; node_count];
    let mut node_level = vec![0_u32; node_count];

    for j in 0..ny {
        let data_row = j * nx;
        let edge_row = j * (nx - 1);
        for i in 0..(nx - 1) {
            fill_horizontal_nodes(
                ranges[edge_row + i],
                values[data_row + i],
                values[data_row + i + 1],
                xs[i],
                xs[i + 1],
                ys[j],
                &levels,
                &mut node_x,
                &mut node_y,
                &mut node_level,
            );
        }
    }
    for j in 0..(ny - 1) {
        let data_row = j * nx;
        let edge_row = horizontal_count + j * nx;
        for i in 0..nx {
            fill_vertical_nodes(
                ranges[edge_row + i],
                values[data_row + i],
                values[data_row + nx + i],
                xs[i],
                ys[j],
                ys[j + 1],
                &levels,
                &mut node_x,
                &mut node_y,
                &mut node_level,
            );
        }
    }

    // Phase 2: cell topology becomes fixed two-slot node adjacency.
    let mut adjacency = vec![[INVALID_NODE; 2]; node_count];
    let mut degree = vec![0_u8; node_count];

    for j in 0..(ny - 1) {
        let row = j * nx;
        for i in 0..(nx - 1) {
            let sw = values[row + i];
            let se = values[row + i + 1];
            let nw = values[row + nx + i];
            let ne = values[row + nx + i + 1];
            if !(sw.is_finite() && se.is_finite() && ne.is_finite() && nw.is_finite()) {
                stats.cells_skipped_non_finite += 1;
                continue;
            }
            stats.cells_finite += 1;

            let minimum = sw.min(se).min(ne).min(nw);
            let maximum = sw.max(se).max(ne).max(nw);
            let first_level = lower_bound(&levels, minimum);
            let end_level = lower_bound(&levels, maximum);
            if first_level == end_level {
                continue;
            }

            let cell_edges = [
                j * (nx - 1) + i,
                horizontal_count + j * nx + i + 1,
                (j + 1) * (nx - 1) + i,
                horizontal_count + j * nx + i,
            ];

            for level_index in first_level..end_level {
                let level = levels[level_index];
                let case_index = u8::from(sw > level)
                    | (u8::from(se > level) << 1)
                    | (u8::from(ne > level) << 2)
                    | (u8::from(nw > level) << 3);

                match case_index {
                    0 | 15 => {}
                    1 => connect_pair(CellEdge::South, CellEdge::West, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?,
                    2 => connect_pair(CellEdge::South, CellEdge::East, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?,
                    3 => connect_pair(CellEdge::West, CellEdge::East, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?,
                    4 => connect_pair(CellEdge::East, CellEdge::North, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?,
                    5 | 10 => {
                        let q = asymptotic_q(sw, se, ne, nw, level);
                        let se_nw_pairing = if q > 0.0 {
                            true
                        } else if q < 0.0 {
                            false
                        } else {
                            ((i ^ j ^ level_index) & 1) == 0
                        };
                        if se_nw_pairing {
                            connect_pair(CellEdge::South, CellEdge::East, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?;
                            connect_pair(CellEdge::North, CellEdge::West, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?;
                        } else {
                            connect_pair(CellEdge::South, CellEdge::West, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?;
                            connect_pair(CellEdge::East, CellEdge::North, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?;
                        }
                    }
                    6 => connect_pair(CellEdge::South, CellEdge::North, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?,
                    7 => connect_pair(CellEdge::West, CellEdge::North, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?,
                    8 => connect_pair(CellEdge::North, CellEdge::West, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?,
                    9 => connect_pair(CellEdge::South, CellEdge::North, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?,
                    11 => connect_pair(CellEdge::East, CellEdge::North, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?,
                    12 => connect_pair(CellEdge::West, CellEdge::East, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?,
                    13 => connect_pair(CellEdge::South, CellEdge::East, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?,
                    14 => connect_pair(CellEdge::South, CellEdge::West, &cell_edges, level_index, &ranges, &node_level, &mut adjacency, &mut degree, &mut stats)?,
                    _ => unreachable!(),
                }
            }
        }
    }

    stats.connected_crossings = degree.iter().filter(|&&value| value != 0).count();

    // Phase 3: emit open chains, then closed cycles.
    let mut output = PackedContours {
        levels,
        path_offsets: vec![0],
        stats,
        ..PackedContours::default()
    };
    let mut visited = vec![false; node_count];
    for node in 0..node_count {
        if degree[node] == 1 && !visited[node] {
            emit_path(
                node as u32,
                &adjacency,
                &degree,
                &node_x,
                &node_y,
                &node_level,
                &mut visited,
                &mut output,
            )?;
        }
    }
    for node in 0..node_count {
        if degree[node] == 2 && !visited[node] {
            emit_path(
                node as u32,
                &adjacency,
                &degree,
                &node_x,
                &node_y,
                &node_level,
                &mut visited,
                &mut output,
            )?;
        }
    }

    output.validate()?;
    Ok(output)
}

pub(crate) fn validate_inputs(
    values: &[f32],
    nx: usize,
    ny: usize,
    xs: &[f32],
    ys: &[f32],
) -> Result<(), ContourError> {
    if nx < 2 || ny < 2 {
        return Err(ContourError::GridTooSmall { nx, ny });
    }
    let expected = nx.checked_mul(ny).ok_or(ContourError::SizeOverflow)?;
    if values.len() != expected {
        return Err(ContourError::DataLength {
            expected,
            actual: values.len(),
        });
    }
    if xs.len() != nx {
        return Err(ContourError::XLength {
            expected: nx,
            actual: xs.len(),
        });
    }
    if ys.len() != ny {
        return Err(ContourError::YLength {
            expected: ny,
            actual: ys.len(),
        });
    }
    if let Some(index) = xs.iter().position(|value| !value.is_finite()) {
        return Err(ContourError::NonFiniteX(index));
    }
    if let Some(index) = ys.iter().position(|value| !value.is_finite()) {
        return Err(ContourError::NonFiniteY(index));
    }
    Ok(())
}

fn lower_bound(values: &[f32], target: f32) -> usize {
    let mut low = 0_usize;
    let mut high = values.len();
    while low < high {
        let middle = low + (high - low) / 2;
        if values[middle] < target {
            low = middle + 1;
        } else {
            high = middle;
        }
    }
    low
}

fn crossing_range(a: f32, b: f32, levels: &[f32]) -> EdgeRange {
    if !a.is_finite() || !b.is_finite() || a == b {
        return EdgeRange::default();
    }
    let first = lower_bound(levels, a.min(b));
    let end = lower_bound(levels, a.max(b));
    EdgeRange {
        first: first as u32,
        count: (end - first) as u32,
        base: 0,
    }
}

fn next_down(value: f32) -> f32 {
    if value.is_nan() || value == f32::NEG_INFINITY {
        value
    } else if value == 0.0 {
        -f32::from_bits(1)
    } else if value > 0.0 {
        f32::from_bits(value.to_bits() - 1)
    } else {
        f32::from_bits(value.to_bits() + 1)
    }
}

fn tie_below(value: f32, level: f32) -> f32 {
    if value == level {
        next_down(value)
    } else {
        value
    }
}

fn interpolation_fraction(a: f32, b: f32, level: f32) -> f32 {
    let a = tie_below(a, level) as f64;
    let b = tie_below(b, level) as f64;
    let level = level as f64;
    let denominator = b - a;
    if denominator == 0.0 || !denominator.is_finite() {
        0.5
    } else {
        ((level - a) / denominator).clamp(0.0, 1.0) as f32
    }
}

#[allow(clippy::too_many_arguments)]
fn fill_horizontal_nodes(
    range: EdgeRange,
    a: f32,
    b: f32,
    x0: f32,
    x1: f32,
    y: f32,
    levels: &[f32],
    node_x: &mut [f32],
    node_y: &mut [f32],
    node_level: &mut [u32],
) {
    for offset in 0..range.count {
        let level_index = range.first + offset;
        let node = (range.base + offset) as usize;
        let t = interpolation_fraction(a, b, levels[level_index as usize]);
        node_x[node] = x0 + t * (x1 - x0);
        node_y[node] = y;
        node_level[node] = level_index;
    }
}

#[allow(clippy::too_many_arguments)]
fn fill_vertical_nodes(
    range: EdgeRange,
    a: f32,
    b: f32,
    x: f32,
    y0: f32,
    y1: f32,
    levels: &[f32],
    node_x: &mut [f32],
    node_y: &mut [f32],
    node_level: &mut [u32],
) {
    for offset in 0..range.count {
        let level_index = range.first + offset;
        let node = (range.base + offset) as usize;
        let t = interpolation_fraction(a, b, levels[level_index as usize]);
        node_x[node] = x;
        node_y[node] = y0 + t * (y1 - y0);
        node_level[node] = level_index;
    }
}

#[allow(clippy::too_many_arguments)]
fn connect_pair(
    edge_a: CellEdge,
    edge_b: CellEdge,
    cell_edges: &[usize; 4],
    level_index: usize,
    ranges: &[EdgeRange],
    node_level: &[u32],
    adjacency: &mut [[u32; 2]],
    degree: &mut [u8],
    stats: &mut ContourStats,
) -> Result<(), ContourError> {
    let edge_id_a = cell_edges[edge_a as usize];
    let edge_id_b = cell_edges[edge_b as usize];
    let node_a = ranges[edge_id_a]
        .node_for(level_index)
        .ok_or(ContourError::MissingCrossing {
            edge: edge_id_a,
            level: level_index,
        })?;
    let node_b = ranges[edge_id_b]
        .node_for(level_index)
        .ok_or(ContourError::MissingCrossing {
            edge: edge_id_b,
            level: level_index,
        })?;
    if connect_nodes(node_a, node_b, node_level, adjacency, degree)? {
        stats.segment_count += 1;
    }
    Ok(())
}

fn connect_nodes(
    node_a: u32,
    node_b: u32,
    node_level: &[u32],
    adjacency: &mut [[u32; 2]],
    degree: &mut [u8],
) -> Result<bool, ContourError> {
    if node_a == node_b {
        return Err(ContourError::Invariant("self-connected contour segment"));
    }
    if node_level[node_a as usize] != node_level[node_b as usize] {
        return Err(ContourError::LevelMismatch { node_a, node_b });
    }
    if adjacency[node_a as usize].contains(&node_b)
        && adjacency[node_b as usize].contains(&node_a)
    {
        return Ok(false);
    }
    if degree[node_a as usize] >= 2 {
        return Err(ContourError::DegreeOverflow(node_a));
    }
    if degree[node_b as usize] >= 2 {
        return Err(ContourError::DegreeOverflow(node_b));
    }

    let slot_a = degree[node_a as usize] as usize;
    let slot_b = degree[node_b as usize] as usize;
    adjacency[node_a as usize][slot_a] = node_b;
    adjacency[node_b as usize][slot_b] = node_a;
    degree[node_a as usize] += 1;
    degree[node_b as usize] += 1;
    Ok(true)
}

fn asymptotic_q(sw: f32, se: f32, ne: f32, nw: f32, level: f32) -> f64 {
    let sw = tie_below(sw, level) as f64 - level as f64;
    let se = tie_below(se, level) as f64 - level as f64;
    let ne = tie_below(ne, level) as f64 - level as f64;
    let nw = tie_below(nw, level) as f64 - level as f64;
    sw * ne - se * nw
}

fn next_neighbor(
    node: u32,
    previous: u32,
    adjacency: &[[u32; 2]],
    degree: &[u8],
) -> u32 {
    let neighbors = adjacency[node as usize];
    match degree[node as usize] {
        0 => INVALID_NODE,
        1 => {
            if neighbors[0] == previous {
                INVALID_NODE
            } else {
                neighbors[0]
            }
        }
        2 => {
            if previous == INVALID_NODE {
                neighbors[0].min(neighbors[1])
            } else if neighbors[0] != previous {
                neighbors[0]
            } else {
                neighbors[1]
            }
        }
        _ => INVALID_NODE,
    }
}

#[allow(clippy::too_many_arguments)]
fn emit_path(
    start: u32,
    adjacency: &[[u32; 2]],
    degree: &[u8],
    node_x: &[f32],
    node_y: &[f32],
    node_level: &[u32],
    visited: &mut [bool],
    output: &mut PackedContours,
) -> Result<(), ContourError> {
    if visited[start as usize] || degree[start as usize] == 0 {
        return Ok(());
    }

    let first_point = output.point_count();
    let path_level = node_level[start as usize];
    let mut previous = INVALID_NODE;
    let mut current = start;
    let mut closed = false;

    loop {
        let index = current as usize;
        if visited[index] {
            closed = current == start;
            break;
        }
        if node_level[index] != path_level {
            return Err(ContourError::Invariant("path walk crossed contour levels"));
        }

        visited[index] = true;
        output.vertices.push(node_x[index]);
        output.vertices.push(node_y[index]);

        let next = next_neighbor(current, previous, adjacency, degree);
        if next == INVALID_NODE {
            break;
        }
        previous = current;
        current = next;
    }

    let point_count = output.point_count() - first_point;
    if point_count < 2 {
        output.vertices.truncate(first_point * 2);
        return Ok(());
    }

    output.path_level_indices.push(path_level);
    output
        .path_flags
        .push(if closed { CLOSED_PATH_FLAG } else { 0 });
    let path_end = output.point_count() as u32;
    output.path_offsets.push(path_end);
    if closed {
        output.stats.closed_path_count += 1;
    } else {
        output.stats.open_path_count += 1;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn coords(count: usize) -> Vec<f32> {
        (0..count).map(|value| value as f32).collect()
    }

    fn path_points(output: &PackedContours, path: usize) -> Vec<(f32, f32)> {
        let begin = output.path_offsets[path] as usize;
        let end = output.path_offsets[path + 1] as usize;
        (begin..end)
            .map(|point| (output.vertices[2 * point], output.vertices[2 * point + 1]))
            .collect()
    }

    #[test]
    fn plane_is_one_open_chain() {
        let values = [
            0.0, 1.0, 2.0,
            1.0, 2.0, 3.0,
            2.0, 3.0, 4.0,
        ];
        let output = contour_levels(&values, 3, 3, &coords(3), &coords(3), &[1.5]).unwrap();
        output.validate().unwrap();
        assert_eq!(output.path_count(), 1);
        assert!(!output.path_is_closed(0));
        assert_eq!(output.stats.segment_count, 3);
    }

    #[test]
    fn hill_is_one_closed_cycle() {
        let nx = 7;
        let ny = 7;
        let mut values = Vec::with_capacity(nx * ny);
        for j in 0..ny {
            for i in 0..nx {
                let dx = i as f32 - 3.0;
                let dy = j as f32 - 3.0;
                values.push(-(dx * dx + dy * dy));
            }
        }
        let output = contour_levels(&values, nx, ny, &coords(nx), &coords(ny), &[-6.5]).unwrap();
        assert_eq!(output.path_count(), 1);
        assert!(output.path_is_closed(0));
        assert_eq!(output.stats.closed_path_count, 1);
    }

    #[test]
    fn asymptotic_decider_connects_strong_positive_diagonal() {
        // SW and NE are strongly positive. Q > 0 selects S-E and N-W.
        let values = [10.0, -1.0, -1.0, 10.0];
        let output = contour_levels(
            &values,
            2,
            2,
            &[0.0, 1.0],
            &[0.0, 1.0],
            &[0.0],
        )
        .unwrap();
        assert_eq!(output.path_count(), 2);
        assert_eq!(output.stats.segment_count, 2);
        for path in 0..2 {
            assert_eq!(path_points(&output, path).len(), 2);
        }
    }

    #[test]
    fn nan_cell_breaks_contours_without_branching() {
        let values = [
            0.0, 1.0, f32::NAN, 3.0,
            0.0, 1.0, 2.0,      3.0,
            0.0, 1.0, 2.0,      3.0,
        ];
        let output = contour_levels(&values, 4, 3, &coords(4), &coords(3), &[1.5]).unwrap();
        output.validate().unwrap();
        assert!(output.stats.cells_skipped_non_finite > 0);
    }

    #[test]
    fn regular_levels_match_zero_anchored_weather_intervals() {
        let levels = interval_levels(&[-2.2, 7.9, f32::NAN], 2.0, 0.0).unwrap();
        assert_eq!(levels, vec![-2.0, 0.0, 2.0, 4.0, 6.0]);
    }
}
