/* Inserted into autumnplot-gl/public/main.js by install-current-upstream-demo.mjs. */
async function makeWeatherContoursSotaLayers() {
    const nx = 721;
    const ny = 421;
    const frameCount = 12;
    const grid = new apgl.PlateCarreeGrid(nx, ny, -130, 20, -60, 58);
    const levels = [-24, -20, -16, -12, -8, -4, 0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40];
    const colors = [
        '#313695', '#3f66b5', '#528bc6', '#6db0d2',
        '#91cfda', '#b7e4df', '#d9efdf', '#f7f7c6',
        '#fee89a', '#fdbf6f', '#f98e52', '#ed5a3a',
        '#d73027', '#b51f2e', '#8e1530', '#5e1028',
    ];
    const cmap = new apgl.ColorMap(levels, colors, {
        underflow_color: '#29245f',
        overflow_color: '#3d071c',
    });

    function makeData(phase) {
        const data = new Float32Array(nx * ny);
        for (let j = 0; j < ny; j++) {
            const y = j / (ny - 1);
            for (let i = 0; i < nx; i++) {
                const x = i / (nx - 1);
                const wave = 7 * Math.sin(2 * Math.PI * x + phase)
                    + 5 * Math.cos(3 * Math.PI * y - 0.4 * phase);
                const front = 13 * Math.tanh((x - 0.56) * 24 + (y - 0.48) * 10 - 0.5 * Math.sin(phase));
                const dx = x - (0.32 + 0.035 * Math.cos(phase));
                const dy = y - (0.62 + 0.025 * Math.sin(phase));
                const low = -18 * Math.exp(-(dx * dx / 0.007 + dy * dy / 0.016));
                const convection = 3.5 * Math.sin(21 * x + 9 * y + 1.7 * phase) * Math.cos(6 * y);
                data[i + nx * j] = wave + front + low + convection;
            }
        }
        return data;
    }

    const fields = Array.from({length: frameCount}, (_, index) => (
        new apgl.RawScalarField(grid, makeData(2 * Math.PI * index / frameCount))
    ));
    let activeFrame = 0;

    const contours = new apgl.WeatherContours(fields[0], {
        cmap,
        opacity: 0.92,
        lines: true,
        line_mode: 'auto',
        line_color: '#171717',
        line_width: 0.9,
        line_opacity: 0.8,
        major_every: 4,
        major_line_color: '#000000',
        major_line_width: 1.8,
        line_feather: 0.7,
    });

    const cpuSubmitMs = [];
    const uploadMs = [];
    const frameIntervalsMs = [];
    const originalRender = contours.render.bind(contours);
    contours.render = (gl, arg) => {
        const started = performance.now();
        originalRender(gl, arg);
        cpuSubmitMs.push(performance.now() - started);
        if (cpuSubmitMs.length > 600) cpuSubmitMs.shift();
    };

    function quantile(values, q) {
        if (values.length === 0) return NaN;
        const ordered = [...values].sort((a, b) => a - b);
        return ordered[Math.round((ordered.length - 1) * q)];
    }

    function telemetryPanel() {
        let panel = document.querySelector('#weather-contours-sota-telemetry');
        if (panel !== null) return panel;
        panel = document.createElement('pre');
        panel.id = 'weather-contours-sota-telemetry';
        Object.assign(panel.style, {
            position: 'absolute',
            zIndex: 10,
            top: '8px',
            right: '8px',
            margin: 0,
            padding: '10px 12px',
            background: 'rgba(8, 12, 18, 0.84)',
            color: '#f4f7fb',
            font: '12px/1.45 ui-monospace, SFMono-Regular, Consolas, monospace',
            borderRadius: '5px',
            pointerEvents: 'none',
            minWidth: '285px',
        });
        document.body.appendChild(panel);
        return panel;
    }

    let layer;
    const originalOnAdd = contours.onAdd.bind(contours);
    contours.onAdd = async (map, gl) => {
        await originalOnAdd(map, gl);
        const panel = telemetryPanel();
        let lastMapFrame = performance.now();
        let renderEvents = 0;
        const onRender = () => {
            const now = performance.now();
            frameIntervalsMs.push(now - lastMapFrame);
            lastMapFrame = now;
            renderEvents += 1;
            if (frameIntervalsMs.length > 600) frameIntervalsMs.shift();
            if (renderEvents % 10 === 0) {
                const frameWindow = frameIntervalsMs.filter(value => value < 500);
                panel.textContent = [
                    'AutumnPlot WeatherContours E2E',
                    `grid                 ${nx} x ${ny}`,
                    `boundaries / bands   ${levels.length} / ${levels.length - 1}`,
                    `renderer             ${contours.renderer || 'initializing'}`,
                    `line mode            ${contours.resolvedLineMode}${contours.isAutoTuning ? ' (tuning)' : ''}`,
                    `field interpolation   ${contours.usesManualBilinearFiltering ? 'manual bilinear' : 'hardware linear'}`,
                    `max EOD bracket       ${contours.maximumDirectorySpan}`,
                    `map frame p50 / p95   ${quantile(frameWindow, 0.50).toFixed(2)} / ${quantile(frameWindow, 0.95).toFixed(2)} ms`,
                    `JS submit p50 / p95   ${quantile(cpuSubmitMs, 0.50).toFixed(3)} / ${quantile(cpuSubmitMs, 0.95).toFixed(3)} ms`,
                    `field upload p50/p95  ${quantile(uploadMs, 0.50).toFixed(2)} / ${quantile(uploadMs, 0.95).toFixed(2)} ms`,
                    `animated frame        ${activeFrame + 1} / ${frameCount}`,
                ].join('\n');
            }
        };
        map.on('render', onRender);

        // Run a bounded real update loop so changing views cannot leave a
        // permanent background animation behind.
        let updates = 0;
        let updating = false;
        const timer = window.setInterval(async () => {
            if (updates >= 80) {
                window.clearInterval(timer);
                return;
            }
            if (updating) return;
            updating = true;
            try {
                activeFrame = (activeFrame + 1) % frameCount;
                const started = performance.now();
                await contours.updateField(fields[activeFrame]);
                uploadMs.push(performance.now() - started);
                if (uploadMs.length > 200) uploadMs.shift();
                updates += 1;
            }
            finally {
                updating = false;
            }
        }, 250);
        layer.onRemove = () => {
            window.clearInterval(timer);
            map.off('render', onRender);
            panel.remove();
        };
    };

    layer = new apgl.PlotLayer('weather-contours-sota', contours);
    const colorbar = apgl.makeColorBar(cmap, {
        label: 'Synthetic weather field — exact contour bands',
        ticks: levels,
        fontface: 'Trebuchet MS',
        orientation: 'horizontal',
        tick_direction: 'bottom',
    });

    return {
        layers: [layer],
        colorbar: [colorbar],
        sampler: (lon, lat) => ({
            value: fields[activeFrame].sampleField(lon, lat).toFixed(2),
            line_mode: contours.resolvedLineMode,
        }),
    };
}
