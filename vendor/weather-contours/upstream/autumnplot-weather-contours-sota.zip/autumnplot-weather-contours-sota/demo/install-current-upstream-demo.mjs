#!/usr/bin/env node
import {execFileSync} from 'node:child_process';
import {existsSync, readFileSync, writeFileSync} from 'node:fs';
import {dirname, join, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const PINNED = 'ee93a7278c0f38026ea61d2ce2c1d6a21893d723';
const root = resolve(process.argv[2] ?? '.');
const here = dirname(fileURLToPath(import.meta.url));
const target = join(root, 'public', 'main.js');
const backup = join(root, '.autumnplot-weather-contours-demo-main.js');
const begin = '// WEATHER-CONTOURS-SOTA-DEMO:BEGIN';
const end = '// WEATHER-CONTOURS-SOTA-DEMO:END';
const head = execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim();
if (head !== PINNED && !process.argv.includes('--force')) {
    throw new Error(`Expected autumnplot-gl ${PINNED}; found ${head}. Pass --force only after reviewing anchors.`);
}
let source = readFileSync(target, 'utf8');
if (source.includes(begin)) {
    console.log('SOTA demo already installed.');
    process.exit(0);
}
if (existsSync(backup)) {
    throw new Error(`Refusing to overwrite existing demo backup: ${backup}`);
}
const original = source;
const demo = readFileSync(join(here, 'autumnplot-e2e.js'), 'utf8');
const viewsAnchor = '\nconst views = {';
if (!source.includes(viewsAnchor)) throw new Error('Could not find current-upstream views anchor.');
source = source.replace(viewsAnchor, `\n${begin}\n${demo}\n${end}\n${viewsAnchor}`);
const entryAnchor = "const views = {\n";
if (!source.includes(entryAnchor)) throw new Error('Could not insert the demo view.');
source = source.replace(entryAnchor, `${entryAnchor}    'weather-contours-sota': {\n        name: \"WeatherContours SOTA\",\n        makeLayers: makeWeatherContoursSotaLayers,\n        maxZoom: 7,\n    },\n`);
writeFileSync(backup, original);
writeFileSync(target, source);
console.log(`Installed selectable WeatherContours SOTA demo into ${target}`);
