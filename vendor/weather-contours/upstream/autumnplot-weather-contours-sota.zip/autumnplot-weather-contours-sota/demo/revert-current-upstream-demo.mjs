#!/usr/bin/env node
import {existsSync, readFileSync, rmSync, writeFileSync} from 'node:fs';
import {join, resolve} from 'node:path';

const root = resolve(process.argv[2] ?? '.');
const target = join(root, 'public', 'main.js');
const backup = join(root, '.autumnplot-weather-contours-demo-main.js');
if (!existsSync(backup)) {
    throw new Error(`No demo backup exists at ${backup}`);
}
writeFileSync(target, readFileSync(backup));
rmSync(backup);
console.log(`Reverted WeatherContours SOTA demo in ${target}`);
