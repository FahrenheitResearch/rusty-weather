import {WGLBuffer, WGLTexture} from 'autumn-wgl';

import {PlotComponent, getGLFormatTypeAlignment} from './PlotComponent';
import {Color} from './Color';
import {ColorMap} from './Colormap';
import {ExpressionScalarField} from './RawField';
import {MapLikeType} from './Map';
import {
    RenderMethodArg,
    TypedArray,
    WebGLAnyRenderingContext,
    getRendererData,
    isWebGL2Ctx,
} from './AutumnTypes';
import {applySamplerCodeScalar} from './utils';
import {ShaderProgramManager} from './ShaderManager';
import {DomainBufferGrid} from './grids/DomainBuffer';

const weatherContoursVertexShader = require('./glsl/weather_contours_vertex.glsl');
const weatherContoursFragmentShader = require('./glsl/weather_contours_fragment.glsl');
const weatherContourLinesFragmentShader = require('./glsl/weather_contour_lines_fragment.glsl');

const MAX_EXPLICIT_LEVELS = 4096;
const ORDINAL_DIRECTORY_SIZE = 256;
const FLOAT32_BITS = new DataView(new ArrayBuffer(4));

type ContourProgram = ReturnType<ShaderProgramManager['getShaderProgram']>;

export type WeatherContourLineMode = 'auto' | 'fused' | 'split';
export type ResolvedWeatherContourLineMode = 'none' | 'fused' | 'split';
type LevelLayout = 'regular' | 'explicit' | 'mixed';
type TimedLineMode = 'fused' | 'split';

/** Optional screen-space isolines drawn directly from the scalar texture. */
export interface WeatherContourLineOptions {
    /** Draw an isoline at every color-map boundary. @default false */
    lines?: boolean;
    /**
     * `fused` shades bands and lines in one pass; `split` uses two specialized
     * passes; `auto` measures both with GPU timer queries and caches the winner.
     * @default 'auto'
     */
    line_mode?: WeatherContourLineMode;
    /** Minor isoline color. @default '#202020' */
    line_color?: Color | string;
    /** Minor isoline width in screen pixels. @default 1 */
    line_width?: number;
    /** Minor and major line opacity. @default 1 */
    line_opacity?: number;
    /** Every Nth boundary is major. Zero disables major lines. @default 5 */
    major_every?: number;
    /** Boundary ordinal treated as the major-line origin. @default 0 */
    major_offset?: number;
    /** Major isoline color. Defaults to line_color. */
    major_line_color?: Color | string | null;
    /** Major isoline width in screen pixels. @default 1.8 */
    major_line_width?: number;
    /** Antialias feather in screen pixels. @default 0.75 */
    line_feather?: number;
}

/** Drop-in options for exact GPU filled contours. */
export interface WeatherContoursOptions extends WeatherContourLineOptions {
    /** One color map, or multiple maps selected by cmap_mask. */
    cmap: ColorMap | ColorMap[];
    /** 1-based color-map selector on the same grid as the field; zero is transparent. */
    cmap_mask?: Uint8Array | null;
    /** Filled-band opacity. @default 1 */
    opacity?: number;
}

interface ResolvedLineOptions {
    lines: boolean;
    requestedMode: WeatherContourLineMode;
    lineColor: Color;
    lineWidth: number;
    lineOpacity: number;
    majorEvery: number;
    majorOffset: number;
    majorLineColor: Color;
    majorLineWidth: number;
    lineFeather: number;
}

interface WeatherContoursGLElems<MapType extends MapLikeType> {
    gl: WebGL2RenderingContext;
    map: MapType;
    fillShaderManager: ShaderProgramManager;
    fusedShaderManager: ShaderProgramManager | null;
    lineShaderManager: ShaderProgramManager | null;
    vertices: WGLBuffer;
    texcoords: WGLBuffer;
}

interface DisjointTimerQueryExtension {
    readonly TIME_ELAPSED_EXT: number;
    readonly GPU_DISJOINT_EXT: number;
}

interface WebGLDebugRendererInfo {
    readonly UNMASKED_RENDERER_WEBGL: number;
}

interface PendingTiming {
    query: WebGLQuery;
    mode: TimedLineMode;
}

interface BandMapUniforms {
    [name: string]: number | number[];
}

const autoModeCache = new Map<string, TimedLineMode>();

/** Clear renderer-local fused/split decisions, primarily for profiling. */
export function clearWeatherContourAutoTuneCache(): void {
    autoModeCache.clear();
}

function finitePositive(value: number, name: string): number {
    if (!Number.isFinite(value) || value <= 0) {
        throw new Error(`${name} must be finite and greater than zero; got ${value}.`);
    }
    return value;
}

function unitInterval(value: number, name: string): number {
    if (!Number.isFinite(value)) {
        throw new Error(`${name} must be finite; got ${value}.`);
    }
    return Math.max(0, Math.min(1, value));
}

function resolveLineOptions(options: WeatherContoursOptions): ResolvedLineOptions {
    const requestedMode = options.line_mode ?? 'auto';
    if (requestedMode !== 'auto' && requestedMode !== 'fused' && requestedMode !== 'split') {
        throw new Error(`line_mode must be 'auto', 'fused', or 'split'; got ${requestedMode}.`);
    }
    const lineColor = Color.normalizeColor(options.line_color ?? '#202020');
    const majorLineColor = options.major_line_color === null || options.major_line_color === undefined
        ? lineColor
        : Color.normalizeColor(options.major_line_color);
    const majorEvery = options.major_every ?? 5;
    const majorOffset = options.major_offset ?? 0;
    if (!Number.isInteger(majorEvery) || majorEvery < 0) {
        throw new Error(`major_every must be a non-negative integer; got ${majorEvery}.`);
    }
    if (!Number.isInteger(majorOffset)) {
        throw new Error(`major_offset must be an integer; got ${majorOffset}.`);
    }

    return {
        lines: options.lines ?? false,
        requestedMode,
        lineColor,
        lineWidth: finitePositive(options.line_width ?? 1.0, 'line_width'),
        lineOpacity: unitInterval(options.line_opacity ?? 1.0, 'line_opacity'),
        majorEvery,
        majorOffset,
        majorLineColor,
        majorLineWidth: finitePositive(options.major_line_width ?? 1.8, 'major_line_width'),
        lineFeather: finitePositive(options.line_feather ?? 0.75, 'line_feather'),
    };
}

function normalizedLevels(colormap: ColorMap): Float32Array {
    const levels = new Float32Array(colormap.levels);
    if (levels.length < 2) {
        throw new Error('A contour color map requires at least two level boundaries.');
    }
    if (levels.length > MAX_EXPLICIT_LEVELS) {
        throw new Error(
            `A contour color map may contain at most ${MAX_EXPLICIT_LEVELS} boundaries; got ${levels.length}.`,
        );
    }
    for (let index = 0; index < levels.length; index++) {
        if (!Number.isFinite(levels[index])) {
            throw new Error(`Color-map boundary ${index} is not finite.`);
        }
        if (index > 0 && !(levels[index] > levels[index - 1])) {
            throw new Error(
                'Color-map boundaries must remain strictly increasing after conversion to float32.',
            );
        }
    }
    const span = Math.fround(levels[levels.length - 1] - levels[0]);
    if (!(span > 0) || !Number.isFinite(span)) {
        throw new Error(
            'The complete contour-level span must be finite in float32 so GPU directory normalization is exact.',
        );
    }
    return levels;
}

function exactRegularLayout(levels: Float32Array): {regular: boolean; interval: number} {
    // The O(1) path is deliberately conservative. Require a shared power-of-two
    // scale that turns every boundary into a <=23-bit integer. Multiplication
    // by the ordinal and addition are then exact binary operations even if a
    // driver contracts the expression. Exotic near-regular maps stay explicit.
    const interval = Math.fround(levels[1] - levels[0]);
    if (!(interval > 0)) return {regular: false, interval};

    let exactDyadicScale = false;
    for (let exponent = 0; exponent <= 20; exponent++) {
        const scale = 2 ** exponent;
        const scaled = [...levels, interval].map(value => value * scale);
        if (scaled.every(value => Number.isInteger(value) && Math.abs(value) <= 2 ** 23)) {
            exactDyadicScale = true;
            break;
        }
    }
    if (!exactDyadicScale) return {regular: false, interval};

    for (let index = 0; index < levels.length; index++) {
        const expected = Math.fround(levels[0] + Math.fround(index * interval));
        if (expected !== levels[index]) return {regular: false, interval};
    }
    return {regular: true, interval};
}

function nextDownF32(value: number): number {
    if (Number.isNaN(value) || value === Number.NEGATIVE_INFINITY) return value;
    FLOAT32_BITS.setFloat32(0, value, true);
    let bits = FLOAT32_BITS.getUint32(0, true);
    if (value === 0) bits = 0x80000001;
    else if (value > 0) bits -= 1;
    else bits += 1;
    FLOAT32_BITS.setUint32(0, bits, true);
    return FLOAT32_BITS.getFloat32(0, true);
}

function shaderDirectoryBucket(value: number, minimum: number, maximum: number): number {
    const numerator = Math.fround(value - minimum);
    const denominator = Math.fround(maximum - minimum);
    const normalized = Math.max(0, Math.min(1, Math.fround(numerator / denominator)));
    const scaled = Math.fround(normalized * ORDINAL_DIRECTORY_SIZE);
    return Math.min(Math.floor(scaled), ORDINAL_DIRECTORY_SIZE - 1);
}

/**
 * Exact Ordinal Directory (EOD): each possible float32 upper-bound insertion
 * interval is assigned to every directory bucket it can reach. Expanding by
 * one neighboring bucket makes the bracket robust to driver rounding at bin
 * boundaries. The shader's binary search is therefore exact, not approximate.
 */
function buildOrdinalDirectory(levels: Float32Array): {data: Uint16Array; maxSpan: number} {
    const minimum = levels[0];
    const maximum = levels[levels.length - 1];
    const minimumPosition = new Int32Array(ORDINAL_DIRECTORY_SIZE);
    const maximumPosition = new Int32Array(ORDINAL_DIRECTORY_SIZE);
    minimumPosition.fill(levels.length);
    maximumPosition.fill(-1);

    // Within [minimum, maximum], upper_bound positions are 1..levels.length.
    for (let position = 1; position <= levels.length; position++) {
        const lowerValue = levels[position - 1];
        const upperValue = position < levels.length
            ? Math.max(lowerValue, nextDownF32(levels[position]))
            : maximum;
        let firstBucket = shaderDirectoryBucket(lowerValue, minimum, maximum);
        let lastBucket = shaderDirectoryBucket(upperValue, minimum, maximum);
        if (lastBucket < firstBucket) [firstBucket, lastBucket] = [lastBucket, firstBucket];
        firstBucket = Math.max(0, firstBucket - 1);
        lastBucket = Math.min(ORDINAL_DIRECTORY_SIZE - 1, lastBucket + 1);
        for (let bucket = firstBucket; bucket <= lastBucket; bucket++) {
            minimumPosition[bucket] = Math.min(minimumPosition[bucket], position);
            maximumPosition[bucket] = Math.max(maximumPosition[bucket], position);
        }
    }

    const data = new Uint16Array(ORDINAL_DIRECTORY_SIZE * 2);
    let maxSpan = 0;
    for (let bucket = 0; bucket < ORDINAL_DIRECTORY_SIZE; bucket++) {
        const low = maximumPosition[bucket] < 0 ? 0 : minimumPosition[bucket];
        const high = maximumPosition[bucket] < 0 ? levels.length : maximumPosition[bucket];
        data[2 * bucket] = low;
        data[2 * bucket + 1] = high;
        maxSpan = Math.max(maxSpan, high - low);
    }
    return {data, maxSpan};
}

function colorBytes(color: Color | null): [number, number, number, number] {
    if (color === null) return [0, 0, 0, 0];
    const rgba = color.toRGBATuple();
    return [
        Math.round(255 * rgba[0]),
        Math.round(255 * rgba[1]),
        Math.round(255 * rgba[2]),
        Math.round(255 * rgba[3]),
    ];
}

function validateMask(
    mask: Uint8Array,
    width: number,
    height: number,
    mapCount: number,
): void {
    if (mask.length !== width * height) {
        throw new Error(`cmap_mask has ${mask.length} cells; expected ${width * height}.`);
    }
    for (let index = 0; index < mask.length; index++) {
        if (mask[index] > mapCount) {
            throw new Error(
                `cmap_mask cell ${index} selects color map ${mask[index]}, ` +
                `but only ${mapCount} map(s) exist.`,
            );
        }
    }
}

function rendererDescription(gl: WebGL2RenderingContext): string {
    const debug = gl.getExtension('WEBGL_debug_renderer_info') as WebGLDebugRendererInfo | null;
    if (debug !== null) {
        return String(gl.getParameter(debug.UNMASKED_RENDERER_WEBGL));
    }
    return String(gl.getParameter(gl.RENDERER));
}

/**
 * Renderer-local GPU autotuner. Fused and split output are alpha-equivalent,
 * so initial static frames may alternate while disjoint timer queries measure
 * actual GPU work. Two samples per mode are discarded and five medians decide.
 */
class AdaptiveLineMode {
    private readonly extension: DisjointTimerQueryExtension | null;
    private readonly pending: PendingTiming[] = [];
    private readonly samples: Record<TimedLineMode, number[]> = {fused: [], split: []};
    private readonly seen: Record<TimedLineMode, number> = {fused: 0, split: 0};
    private nextCandidate: TimedLineMode = 'fused';
    private renderAttempts = 0;
    private settled = false;
    private winner: TimedLineMode = 'fused';

    public constructor(
        private readonly gl: WebGL2RenderingContext,
        private readonly cacheKey: string,
    ) {
        const cached = autoModeCache.get(cacheKey);
        if (cached !== undefined) {
            this.winner = cached;
            this.settled = true;
            this.extension = null;
            return;
        }
        this.extension = gl.getExtension(
            'EXT_disjoint_timer_query_webgl2',
        ) as DisjointTimerQueryExtension | null;
        if (this.extension === null || gl.isContextLost()) {
            this.settled = true;
        }
    }

    public get isTuning(): boolean {
        return !this.settled;
    }

    public get selected(): TimedLineMode {
        return this.winner;
    }

    private median(values: readonly number[]): number {
        const ordered = [...values].sort((a, b) => a - b);
        const middle = Math.floor(ordered.length / 2);
        return ordered.length % 2 === 0
            ? 0.5 * (ordered[middle - 1] + ordered[middle])
            : ordered[middle];
    }

    private settle(mode: TimedLineMode): void {
        if (this.settled) return;
        this.winner = mode;
        this.settled = true;
        autoModeCache.set(this.cacheKey, mode);
        for (const timing of this.pending) this.gl.deleteQuery(timing.query);
        this.pending.length = 0;
    }

    private collect(): void {
        if (this.settled || this.extension === null) return;
        if (this.gl.getParameter(this.extension.GPU_DISJOINT_EXT)) {
            for (const timing of this.pending) this.gl.deleteQuery(timing.query);
            this.pending.length = 0;
            this.samples.fused.length = 0;
            this.samples.split.length = 0;
            this.seen.fused = 0;
            this.seen.split = 0;
            return;
        }

        let write = 0;
        for (const timing of this.pending) {
            const available = Boolean(
                this.gl.getQueryParameter(timing.query, this.gl.QUERY_RESULT_AVAILABLE),
            );
            if (!available) {
                this.pending[write++] = timing;
                continue;
            }
            const elapsed = Number(
                this.gl.getQueryParameter(timing.query, this.gl.QUERY_RESULT),
            );
            this.gl.deleteQuery(timing.query);
            this.seen[timing.mode] += 1;
            if (this.seen[timing.mode] > 2 && Number.isFinite(elapsed) && elapsed > 0) {
                this.samples[timing.mode].push(elapsed);
            }
        }
        this.pending.length = write;

        if (this.samples.fused.length >= 5 && this.samples.split.length >= 5) {
            const fused = this.median(this.samples.fused.slice(0, 5));
            const split = this.median(this.samples.split.slice(0, 5));
            this.settle(fused <= split ? 'fused' : 'split');
        }
    }

    public begin(): {mode: TimedLineMode; query: WebGLQuery | null} {
        this.collect();
        if (this.settled || this.extension === null) {
            return {mode: this.winner, query: null};
        }

        this.renderAttempts += 1;
        if (this.renderAttempts > 96) {
            if (this.samples.fused.length > 0 && this.samples.split.length > 0) {
                this.settle(
                    this.median(this.samples.fused) <= this.median(this.samples.split)
                        ? 'fused'
                        : 'split',
                );
            }
            else {
                this.settle('fused');
            }
            return {mode: this.winner, query: null};
        }

        const mode = this.nextCandidate;
        this.nextCandidate = mode === 'fused' ? 'split' : 'fused';
        if (this.pending.length >= 8) return {mode, query: null};

        const query = this.gl.createQuery();
        if (query === null) {
            this.settle('fused');
            return {mode: this.winner, query: null};
        }
        try {
            this.gl.beginQuery(this.extension.TIME_ELAPSED_EXT, query);
            return {mode, query};
        }
        catch {
            this.gl.deleteQuery(query);
            this.settle('fused');
            return {mode: this.winner, query: null};
        }
    }

    public end(mode: TimedLineMode, query: WebGLQuery | null): void {
        if (query === null || this.extension === null || this.settled) return;
        try {
            this.gl.endQuery(this.extension.TIME_ELAPSED_EXT);
            this.pending.push({query, mode});
        }
        catch {
            this.gl.deleteQuery(query);
            this.settle('fused');
        }
    }
}

/** GPU representation of exact thresholds, rank directory, and band colors. */
class ExactBandMapGPU {
    private readonly levels: Float32Array;
    public readonly regular: boolean;
    private readonly interval: number;
    private readonly paletteBytes: Uint8Array;
    private readonly directoryBytes: Uint16Array;
    public readonly directoryMaxSpan: number;
    private levelTexture: WGLTexture | null = null;
    private directoryTexture: WGLTexture | null = null;
    private paletteTexture: WGLTexture | null = null;

    public constructor(private readonly colormap: ColorMap) {
        this.levels = normalizedLevels(colormap);
        if (colormap.colors.length !== this.levels.length - 1) {
            throw new Error(
                `Color map has ${this.levels.length} boundaries but ` +
                `${colormap.colors.length} band colors.`,
            );
        }
        const regularity = exactRegularLayout(this.levels);
        this.regular = regularity.regular;
        this.interval = regularity.interval;
        const directory = buildOrdinalDirectory(this.levels);
        this.directoryBytes = directory.data;
        this.directoryMaxSpan = directory.maxSpan;
        const palette = [
            colorBytes(colormap.underflow_color),
            ...colormap.colors.map(color => colorBytes(color)),
            colorBytes(colormap.overflow_color),
        ];
        this.paletteBytes = new Uint8Array(palette.flat());
    }

    public get boundaryCount(): number {
        return this.levels.length;
    }

    public setup(gl: WebGL2RenderingContext, layout: LevelLayout): void {
        const maximumTextureSize = Number(gl.getParameter(gl.MAX_TEXTURE_SIZE));
        if (this.levels.length > maximumTextureSize || this.paletteBytes.length / 4 > maximumTextureSize) {
            throw new Error('A contour threshold or palette texture exceeds MAX_TEXTURE_SIZE.');
        }
        if (layout !== 'regular') {
            this.levelTexture = new WGLTexture(gl, {
                format: gl.R32F,
                type: gl.FLOAT,
                width: this.levels.length,
                height: 1,
                image: this.levels,
                mag_filter: gl.NEAREST,
                min_filter: gl.NEAREST,
                row_alignment: 4,
            });
            this.directoryTexture = new WGLTexture(gl, {
                format: gl.RG16UI,
                type: gl.UNSIGNED_SHORT,
                width: ORDINAL_DIRECTORY_SIZE,
                height: 1,
                image: this.directoryBytes,
                mag_filter: gl.NEAREST,
                min_filter: gl.NEAREST,
                row_alignment: 2,
            });
        }
        this.paletteTexture = new WGLTexture(gl, {
            format: gl.RGBA8,
            type: gl.UNSIGNED_BYTE,
            width: this.paletteBytes.length / 4,
            height: 1,
            image: this.paletteBytes,
            mag_filter: gl.NEAREST,
            min_filter: gl.NEAREST,
            row_alignment: 1,
        });
    }

    private uniforms(layout: LevelLayout): BandMapUniforms {
        const uniforms: BandMapUniforms = {
            u_level_count: this.levels.length,
            u_band_count: this.colormap.colors.length,
            u_level_min: this.levels[0],
            u_level_max: this.levels[this.levels.length - 1],
        };
        if (layout !== 'explicit') uniforms.u_level_interval = this.interval;
        if (layout === 'mixed') uniforms.u_levels_regular = this.regular ? 1 : 0;
        return uniforms;
    }

    private bindThresholds(program: ContourProgram, layout: LevelLayout): void {
        program.setUniforms(this.uniforms(layout));
        if (layout !== 'regular') {
            if (this.levelTexture === null || this.directoryTexture === null) {
                throw new Error('ExactBandMapGPU.setup() must run before drawing.');
            }
            program.bindTextures({
                u_band_levels: this.levelTexture,
                u_level_directory: this.directoryTexture,
            });
        }
    }

    public bindFill(program: ContourProgram, layout: LevelLayout): void {
        if (this.paletteTexture === null) {
            throw new Error('ExactBandMapGPU.setup() must run before bindFill().');
        }
        this.bindThresholds(program, layout);
        program.bindTextures({u_band_palette: this.paletteTexture});
    }

    public bindLines(program: ContourProgram, layout: LevelLayout): void {
        this.bindThresholds(program, layout);
    }
}

/**
 * Exact, discrete GPU weather contours.
 *
 * Filled bands never construct polygons. Optional lines also remain on the
 * GPU, either fused with the fill or drawn by a second specialized pass.
 * Regular boundaries classify in O(1); irregular boundaries use the exact
 * ordinal directory plus bounded binary search. Rust is used only when true
 * connected line or polygon geometry is requested.
 */
export class WeatherContours<
    ArrayType extends TypedArray,
    GridType extends DomainBufferGrid,
    MapType extends MapLikeType,
> extends PlotComponent<MapType> {
    private field: ExpressionScalarField<ArrayType, GridType>;
    public readonly opts: WeatherContoursOptions;
    public resolvedLineMode: ResolvedWeatherContourLineMode = 'none';
    public renderer = '';

    private readonly opacity: number;
    private readonly lineOptions: ResolvedLineOptions;
    private readonly bandMaps: ExactBandMapGPU[];
    private readonly levelLayout: LevelLayout;
    private readonly gridWidth: number;
    private readonly gridHeight: number;
    private readonly fieldProgramSignature: string;
    private autoTuner: AdaptiveLineMode | null = null;
    private glElems: WeatherContoursGLElems<MapType> | null = null;
    private fieldTextures: Map<string, WGLTexture> | null = null;
    private maskTexture: WGLTexture | null = null;
    private manualBilinear = false;

    public constructor(
        field: ExpressionScalarField<ArrayType, GridType>,
        options: WeatherContoursOptions,
    ) {
        super();
        this.assertField(field);
        this.field = field;
        this.gridWidth = field.grid.ni;
        this.gridHeight = field.grid.nj;
        this.fieldProgramSignature = this.programSignature(field);
        this.opts = options;
        this.opacity = unitInterval(options.opacity ?? 1, 'opacity');
        this.lineOptions = resolveLineOptions(options);
        const colormaps = Array.isArray(options.cmap) ? options.cmap : [options.cmap];
        if (colormaps.length === 0) throw new Error('At least one color map is required.');
        if (colormaps.length > 255) throw new Error('cmap_mask supports at most 255 color maps.');
        if (colormaps.length > 1 && options.cmap_mask == null) {
            throw new Error('Multiple color maps require cmap_mask.');
        }
        if (options.cmap_mask != null) {
            validateMask(options.cmap_mask, this.gridWidth, this.gridHeight, colormaps.length);
        }
        this.bandMaps = colormaps.map(colormap => new ExactBandMapGPU(colormap));
        const regularCount = this.bandMaps.filter(bandMap => bandMap.regular).length;
        this.levelLayout = regularCount === this.bandMaps.length
            ? 'regular'
            : regularCount === 0 ? 'explicit' : 'mixed';
    }

    /** Largest exact-search bracket among this component's irregular color maps. */
    public get maximumDirectorySpan(): number {
        return Math.max(...this.bandMaps.map(bandMap => bandMap.directoryMaxSpan));
    }

    /** True when float32 bilinear interpolation is emulated with four nearest samples. */
    public get usesManualBilinearFiltering(): boolean {
        return this.manualBilinear;
    }

    /** True only during the short renderer-local fused/split calibration. */
    public get isAutoTuning(): boolean {
        return this.autoTuner?.isTuning ?? false;
    }

    private programSignature(field: ExpressionScalarField<ArrayType, GridType>): string {
        return JSON.stringify([field.getSamplerIds(), field.getExpression(), field.dtypes]);
    }

    private assertField(field: ExpressionScalarField<ArrayType, GridType>): void {
        const unsupported = field.dtypes.filter(dtype => dtype !== 'float16' && dtype !== 'float32');
        if (unsupported.length > 0) {
            throw new Error(
                `WeatherContours requires float16/float32 field textures; got ${unsupported.join(', ')}.`,
            );
        }
    }

    private updateMask(gl: WebGL2RenderingContext, mask?: Uint8Array): void {
        if (mask === undefined) return;
        if (this.opts.cmap_mask == null) {
            throw new Error('A mask was supplied to updateField(), but this component has no cmap_mask.');
        }
        validateMask(mask, this.field.grid.ni, this.field.grid.nj, this.bandMaps.length);
        const {format, type, row_alignment} = getGLFormatTypeAlignment(gl, 'uint8');
        const spec = {
            format,
            type,
            width: this.field.grid.ni,
            height: this.field.grid.nj,
            image: mask,
            mag_filter: gl.NEAREST,
            min_filter: gl.NEAREST,
            row_alignment,
        };
        if (this.maskTexture === null) this.maskTexture = new WGLTexture(gl, spec);
        else this.maskTexture.setImageData(spec);
    }

    public async updateField(
        field: ExpressionScalarField<ArrayType, GridType>,
        mask?: Uint8Array,
    ): Promise<void> {
        this.assertField(field);
        if (this.programSignature(field) !== this.fieldProgramSignature) {
            throw new Error(
                'updateField() cannot change the scalar sampler/expression program. ' +
                'Create a new WeatherContours component for a different computed field.',
            );
        }
        if (field.grid.ni !== this.gridWidth || field.grid.nj !== this.gridHeight) {
            throw new Error(
                `updateField() cannot change grid shape from ${this.gridWidth}x${this.gridHeight} ` +
                `to ${field.grid.ni}x${field.grid.nj}. Create a new component instead.`,
            );
        }
        this.field = field;
        if (this.glElems === null) return;
        const gl = this.glElems.gl;
        const interpolation = this.manualBilinear ? gl.NEAREST : gl.LINEAR;
        this.fieldTextures = this.field.updateTexImageData(gl, interpolation, this.fieldTextures);
        this.updateMask(gl, mask);
        this.glElems.map.triggerRepaint();
    }

    public async onAdd(map: MapType, glAny: WebGLAnyRenderingContext): Promise<void> {
        if (!isWebGL2Ctx(glAny)) throw new Error('Exact filled contours require WebGL 2.');
        const gl = glAny as WebGL2RenderingContext;
        const buffers = await this.field.grid.getDomainBuffers(gl);
        this.manualBilinear = this.field.dtypes.includes('float32') &&
            gl.getExtension('OES_texture_float_linear') === null;
        const maskDefines = this.opts.cmap_mask == null ? [] : ['MASK'];
        const layoutDefine = this.levelLayout === 'regular'
            ? 'REGULAR_LEVELS'
            : this.levelLayout === 'explicit' ? 'EXPLICIT_LEVELS' : 'MIXED_LEVELS';
        const samplingDefines = this.manualBilinear ? ['MANUAL_BILINEAR'] : [];
        const baseDefines = [...maskDefines, ...samplingDefines, layoutDefine];
        this.renderer = rendererDescription(gl);

        const fillFragment = applySamplerCodeScalar(
            weatherContoursFragmentShader,
            this.field.getSamplerIds(),
            this.field.getExpression(),
            this.field.dtypes,
        );
        const lineFragment = this.lineOptions.lines
            ? applySamplerCodeScalar(
                weatherContourLinesFragmentShader,
                this.field.getSamplerIds(),
                this.field.getExpression(),
                this.field.dtypes,
            )
            : null;

        this.glElems = {
            gl,
            map,
            fillShaderManager: new ShaderProgramManager(
                weatherContoursVertexShader,
                fillFragment,
                baseDefines,
            ),
            fusedShaderManager: this.lineOptions.lines
                ? new ShaderProgramManager(
                    weatherContoursVertexShader,
                    fillFragment,
                    [...baseDefines, 'CONTOUR_LINES'],
                )
                : null,
            lineShaderManager: lineFragment === null
                ? null
                : new ShaderProgramManager(
                    weatherContoursVertexShader,
                    lineFragment,
                    baseDefines,
                ),
            vertices: buffers.vertices,
            texcoords: buffers.texcoords,
        };

        if (!this.lineOptions.lines) {
            this.resolvedLineMode = 'none';
        }
        else if (this.lineOptions.requestedMode === 'auto') {
            const mapShape = this.bandMaps.map(
                bandMap => `${bandMap.boundaryCount}:${bandMap.directoryMaxSpan}`,
            ).join(',');
            const cacheKey = [
                this.renderer,
                this.levelLayout,
                this.opts.cmap_mask == null ? 'unmasked' : 'masked',
                this.manualBilinear ? 'manual-bilinear' : 'hardware-linear',
                `${this.gridWidth}x${this.gridHeight}`,
                mapShape,
                this.lineOptions.lineWidth,
                this.lineOptions.majorEvery,
                this.lineOptions.majorLineWidth,
                this.lineOptions.lineFeather,
            ].join('|');
            this.autoTuner = new AdaptiveLineMode(gl, cacheKey);
            this.resolvedLineMode = this.autoTuner.selected;
        }
        else {
            this.resolvedLineMode = this.lineOptions.requestedMode;
        }

        this.bandMaps.forEach(bandMap => bandMap.setup(gl, this.levelLayout));
        await this.updateField(this.field, this.opts.cmap_mask ?? undefined);
    }

    private drawWorldCopies(
        program: ContourProgram,
        renderData: ReturnType<typeof getRendererData>,
    ): void {
        program.setUniforms({u_offset: 0});
        program.draw();
        if (renderData.type !== 'maplibre' || !renderData.shaderData.define.includes('GLOBE')) {
            for (const offset of [-2, -1, 1]) {
                program.setUniforms({u_offset: offset});
                program.draw();
            }
        }
    }

    private samplingUniforms(): Record<string, number | number[]> {
        return this.manualBilinear
            ? {u_field_size: [this.gridWidth, this.gridHeight]}
            : {};
    }

    private lineUniforms(): Record<string, number | number[]> {
        const line = this.lineOptions;
        return {
            u_line_color: [...line.lineColor.toRGBATuple()],
            u_line_width: line.lineWidth,
            u_line_opacity: line.lineOpacity,
            u_major_every: line.majorEvery,
            u_major_offset: line.majorOffset,
            u_major_line_color: [...line.majorLineColor.toRGBATuple()],
            u_major_line_width: line.majorLineWidth,
            u_line_feather: line.lineFeather,
        };
    }

    private bindMask(program: ContourProgram, index: number): void {
        if (this.maskTexture !== null) {
            program.setUniforms({u_mask_val: index + 1});
            program.bindTextures({u_mask_sampler: this.maskTexture});
        }
    }

    private drawFillPass(
        gl: WebGL2RenderingContext,
        renderData: ReturnType<typeof getRendererData>,
        attributes: Record<string, WGLBuffer>,
        textures: Record<string, WGLTexture>,
        fused: boolean,
    ): void {
        if (this.glElems === null) return;
        const manager = fused
            ? this.glElems.fusedShaderManager
            : this.glElems.fillShaderManager;
        if (manager === null) throw new Error('Fused contour shader was not initialized.');
        const program = manager.getShaderProgram(gl, renderData.shaderData);
        const uniforms: Record<string, number | number[]> = {
            u_fill_opacity: this.opacity,
            ...this.samplingUniforms(),
            ...manager.getShaderUniforms(renderData),
        };
        if (fused) Object.assign(uniforms, this.lineUniforms());
        program.use(attributes, uniforms, textures);
        gl.enable(gl.BLEND);
        if (fused) {
            gl.blendFuncSeparate(gl.ONE, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
        }
        else {
            gl.blendFuncSeparate(
                gl.SRC_ALPHA,
                gl.ONE_MINUS_SRC_ALPHA,
                gl.ONE,
                gl.ONE_MINUS_SRC_ALPHA,
            );
        }
        this.bandMaps.forEach((bandMap, index) => {
            this.bindMask(program, index);
            bandMap.bindFill(program, this.levelLayout);
            this.drawWorldCopies(program, renderData);
        });
    }

    private drawLinePass(
        gl: WebGL2RenderingContext,
        renderData: ReturnType<typeof getRendererData>,
        attributes: Record<string, WGLBuffer>,
        textures: Record<string, WGLTexture>,
    ): void {
        if (this.glElems === null || this.glElems.lineShaderManager === null) return;
        const manager = this.glElems.lineShaderManager;
        const program = manager.getShaderProgram(gl, renderData.shaderData);
        program.use(
            attributes,
            {
                ...this.lineUniforms(),
                ...this.samplingUniforms(),
                ...manager.getShaderUniforms(renderData),
            },
            textures,
        );
        gl.enable(gl.BLEND);
        gl.blendFuncSeparate(gl.ONE, gl.ONE_MINUS_SRC_ALPHA, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
        this.bandMaps.forEach((bandMap, index) => {
            this.bindMask(program, index);
            bandMap.bindLines(program, this.levelLayout);
            this.drawWorldCopies(program, renderData);
        });
    }

    public render(glAny: WebGLAnyRenderingContext, arg: RenderMethodArg): void {
        if (this.glElems === null || this.fieldTextures === null || !isWebGL2Ctx(glAny)) return;
        const gl = glAny as WebGL2RenderingContext;
        const renderData = getRendererData(arg);
        const attributes = {
            a_pos: this.glElems.vertices,
            a_tex_coord: this.glElems.texcoords,
        };
        const textures = Object.fromEntries(
            this.fieldTextures.entries(),
        ) as Record<string, WGLTexture>;

        let mode = this.resolvedLineMode;
        let timingQuery: WebGLQuery | null = null;
        if (this.autoTuner !== null) {
            const timing = this.autoTuner.begin();
            mode = timing.mode;
            timingQuery = timing.query;
            this.resolvedLineMode = mode;
        }

        if (mode === 'fused') {
            this.drawFillPass(gl, renderData, attributes, textures, true);
        }
        else {
            this.drawFillPass(gl, renderData, attributes, textures, false);
            if (mode === 'split') this.drawLinePass(gl, renderData, attributes, textures);
        }

        if (this.autoTuner !== null) {
            this.autoTuner.end(mode as TimedLineMode, timingQuery);
            if (this.autoTuner.isTuning) this.glElems.map.triggerRepaint();
            else this.resolvedLineMode = this.autoTuner.selected;
        }
    }
}
