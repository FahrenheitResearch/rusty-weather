#version 300 es

uniform int u_offset;

in vec2 a_pos;
in vec2 a_tex_coord;

out highp vec2 v_tex_coord;

void main() {
    vec2 world_offset = vec2(float(u_offset), 0.0);
    gl_Position = projectTile(a_pos + world_offset);
    v_tex_coord = a_tex_coord;
}
