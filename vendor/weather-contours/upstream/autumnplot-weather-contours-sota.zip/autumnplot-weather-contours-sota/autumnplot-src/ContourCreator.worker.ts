import * as Comlink from 'comlink';

import {ContourData, ContourableTypedArray} from './AutumnTypes';
import {GridCoords} from './grids/Grid';
import {loadWeatherContoursWasm, WeatherContoursWasm} from './WeatherContoursWasm';

let geometryPromise: Promise<WeatherContoursWasm> | null = null;
let halfLookup: Float32Array | null = null;
let warnedQuadAsTri = false;

const MAX_COMPATIBILITY_LEVELS = 65_536;
type WorkerContourData = ContourableTypedArray | Uint16Array;

/** Options for RawScalarField.getContours(). Explicit levels override interval. */
export interface FieldContourOpts {
    interval?: number;
    levels?: number[];
    /** Retained for source compatibility; OIRT always uses bilinear saddle topology. */
    quad_as_tri?: boolean;
}

function resolveWasmUrl(baseUrl: string | undefined): string {
    if (baseUrl !== undefined) {
        if (baseUrl.endsWith('.wasm')) return baseUrl;
        return `${baseUrl}${baseUrl.endsWith('/') ? '' : '/'}weather_contours.wasm`;
    }
    return new URL('weather_contours.wasm', self.location.href).toString();
}

async function init(wasmBaseUrl: string | undefined): Promise<void> {
    if (geometryPromise === null) {
        geometryPromise = loadWeatherContoursWasm(resolveWasmUrl(wasmBaseUrl));
    }
    await geometryPromise;
}

function halfBitsToFloatBits(value: number): number {
    const sign = (value & 0x8000) << 16;
    let exponent = (value >>> 10) & 0x1f;
    let mantissa = value & 0x03ff;
    if (exponent === 0) {
        if (mantissa === 0) return sign >>> 0;
        exponent = 1;
        while ((mantissa & 0x0400) === 0) {
            mantissa <<= 1;
            exponent -= 1;
        }
        mantissa &= 0x03ff;
        return (sign | ((exponent + 112) << 23) | (mantissa << 13)) >>> 0;
    }
    if (exponent === 0x1f) {
        return (sign | 0x7f800000 | (mantissa << 13)) >>> 0;
    }
    return (sign | ((exponent + 112) << 23) | (mantissa << 13)) >>> 0;
}

function getHalfLookup(): Float32Array {
    if (halfLookup !== null) return halfLookup;
    const values = new Float32Array(1 << 16);
    const bits = new Uint32Array(values.buffer);
    for (let value = 0; value < 1 << 16; value++) {
        bits[value] = halfBitsToFloatBits(value);
    }
    halfLookup = values;
    return values;
}

function asFloat32(data: WorkerContourData): Float32Array {
    if (data instanceof Float32Array) return data;
    if (!(data instanceof Uint16Array)) {
        // Defensive support for a directly supplied Float16Array object. The
        // normal RawScalarField worker path transfers its underlying Uint16Array.
        return Float32Array.from(data as unknown as ArrayLike<number>);
    }
    const lookup = getHalfLookup();
    const output = new Float32Array(data.length);
    for (let index = 0; index < data.length; index++) output[index] = lookup[data[index]];
    return output;
}

function intervalLevels(values: Float32Array, interval: number, anchor = 0): Float32Array {
    if (!Number.isFinite(interval) || interval <= 0) {
        throw new Error(`Contour interval must be finite and positive; got ${interval}.`);
    }
    let minimum = Number.POSITIVE_INFINITY;
    let maximum = Number.NEGATIVE_INFINITY;
    for (const value of values) {
        if (Number.isFinite(value)) {
            minimum = Math.min(minimum, value);
            maximum = Math.max(maximum, value);
        }
    }
    if (!Number.isFinite(minimum) || !Number.isFinite(maximum)) return new Float32Array();
    const first = Math.ceil((minimum - anchor) / interval);
    const last = Math.floor((maximum - anchor) / interval);
    if (first > last) return new Float32Array();
    const count = last - first + 1;
    if (!Number.isSafeInteger(count) || count > MAX_COMPATIBILITY_LEVELS) {
        throw new Error(
            `Contour interval would generate ${count} levels; the compatibility worker limit is ` +
            `${MAX_COMPATIBILITY_LEVELS}.`,
        );
    }
    const output = new Float32Array(count);
    for (let index = 0; index < count; index++) {
        output[index] = Math.fround(anchor + (first + index) * interval);
    }
    return output;
}

function unpackCompatibilityContours(
    levels: Float32Array,
    vertices: Float32Array,
    offsets: Uint32Array,
    pathLevels: Uint32Array,
    flags: Uint8Array,
): ContourData {
    const contours: ContourData = {};
    for (let path = 0; path < pathLevels.length; path++) {
        const level = levels[pathLevels[path]];
        const begin = offsets[path];
        const end = offsets[path + 1];
        const points: [number, number][] = new Array(end - begin + ((flags[path] & 1) !== 0 ? 1 : 0));
        for (let point = begin; point < end; point++) {
            points[point - begin] = [vertices[2 * point], vertices[2 * point + 1]];
        }
        if ((flags[path] & 1) !== 0 && end > begin) {
            points[points.length - 1] = [vertices[2 * begin], vertices[2 * begin + 1]];
        }
        if (!(level in contours)) contours[level] = [];
        contours[level].push(points);
    }
    return contours;
}

async function contourCreator(
    data: WorkerContourData,
    gridCoords: GridCoords,
    options: FieldContourOpts,
): Promise<ContourData> {
    if (options.interval === undefined && options.levels === undefined) {
        throw new Error('Must supply either interval or levels to contourCreator().');
    }
    if (options.quad_as_tri && !warnedQuadAsTri) {
        console.warn(
            'quad_as_tri is ignored by the OIRT worker; ambiguous cells use the bilinear asymptotic decider.',
        );
        warnedQuadAsTri = true;
    }

    const values = asFloat32(data);
    const nx = gridCoords.x.length;
    const ny = gridCoords.y.length;
    if (nx < 2 || ny < 2 || values.length !== nx * ny) {
        throw new Error(
            `Contour grid/data mismatch: ${nx} x ${ny} coordinates for ${values.length} samples.`,
        );
    }
    if (options.levels !== undefined && options.levels.length > MAX_COMPATIBILITY_LEVELS) {
        throw new Error(
            `Explicit contour levels exceed the compatibility worker limit of ` +
            `${MAX_COMPATIBILITY_LEVELS}.`,
        );
    }
    const levels = options.levels === undefined
        ? intervalLevels(values, options.interval as number)
        : new Float32Array(options.levels);
    if (geometryPromise === null) {
        geometryPromise = loadWeatherContoursWasm(resolveWasmUrl(undefined));
    }
    const geometry = await geometryPromise;
    const packed = geometry.contourLevels(
        values,
        nx,
        ny,
        gridCoords.x,
        gridCoords.y,
        levels,
    );
    return unpackCompatibilityContours(
        packed.levels,
        packed.vertices,
        packed.pathOffsets,
        packed.pathLevelIndices,
        packed.pathFlags,
    );
}

const endpoint = {contourCreator, init};
Comlink.expose(endpoint);

export type ContourCreatorWorker = typeof endpoint;
