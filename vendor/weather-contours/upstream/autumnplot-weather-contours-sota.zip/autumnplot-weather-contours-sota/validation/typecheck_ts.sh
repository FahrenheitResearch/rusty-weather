#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/glsl" "$TMP/src/grids" "$TMP/node_modules/autumn-wgl" "$TMP/node_modules/comlink"
cp "$ROOT/autumnplot-src/WeatherContours.ts" "$TMP/src/WeatherContours.ts"
cp "$ROOT/autumnplot-src/WeatherContoursWasm.ts" "$TMP/src/WeatherContoursWasm.ts"
cp "$ROOT/autumnplot-src/ContourCreator.worker.ts" "$TMP/src/ContourCreator.worker.ts"
cp "$ROOT/autumnplot-src/glsl/"*.glsl "$TMP/src/glsl/"

cat > "$TMP/node_modules/autumn-wgl/index.d.ts" <<'STUB'
export class WGLBuffer {}
export class WGLTexture {
    constructor(gl: WebGLRenderingContext | WebGL2RenderingContext, spec: any);
    setImageData(spec: any): void;
}
STUB
cat > "$TMP/node_modules/comlink/index.d.ts" <<'STUB'
export function expose(value: unknown): void;
STUB
cat > "$TMP/src/PlotComponent.d.ts" <<'STUB'
import type {WebGLAnyRenderingContext, RenderMethodArg} from './AutumnTypes';
import type {MapLikeType} from './Map';
export abstract class PlotComponent<MapType extends MapLikeType> {
    abstract onAdd(map: MapType, gl: WebGLAnyRenderingContext): Promise<void>;
    abstract render(gl: WebGLAnyRenderingContext, arg: RenderMethodArg): void;
}
export function getGLFormatTypeAlignment(gl: WebGLAnyRenderingContext, dtype: string): {
    format: number; type: number; row_alignment: number;
};
STUB
cat > "$TMP/src/Color.d.ts" <<'STUB'
export class Color {
    static normalizeColor(value: Color | string): Color;
    toRGBATuple(): [number, number, number, number];
}
STUB
cat > "$TMP/src/Colormap.d.ts" <<'STUB'
import type {Color} from './Color';
export class ColorMap {
    readonly levels: number[];
    readonly colors: Color[];
    readonly overflow_color: Color | null;
    readonly underflow_color: Color | null;
}
STUB
cat > "$TMP/src/Map.d.ts" <<'STUB'
export interface MapLikeType { triggerRepaint(): void; }
STUB
cat > "$TMP/src/AutumnTypes.d.ts" <<'STUB'
export type TypedArray = Float32Array | Uint16Array | Uint8Array | Uint32Array | Int16Array | Int32Array;
export type ContourableTypedArray = Float32Array | Uint16Array;
export type ContourData = Record<number, [number, number][][]>;
export type WebGLAnyRenderingContext = WebGLRenderingContext | WebGL2RenderingContext;
export type RenderMethodArg = unknown;
export interface RendererData {
    type: string;
    shaderData: {define: string[]};
}
export function getRendererData(arg: RenderMethodArg): RendererData;
export function isWebGL2Ctx(gl: WebGLAnyRenderingContext): gl is WebGL2RenderingContext;
STUB
cat > "$TMP/src/grids/Grid.d.ts" <<'STUB'
export interface GridCoords { x: Float32Array; y: Float32Array; }
STUB
cat > "$TMP/src/grids/DomainBuffer.d.ts" <<'STUB'
import type {WGLBuffer} from 'autumn-wgl';
export interface DomainBufferGrid {
    readonly ni: number;
    readonly nj: number;
    getDomainBuffers(gl: WebGL2RenderingContext): Promise<{vertices: WGLBuffer; texcoords: WGLBuffer}>;
}
STUB
cat > "$TMP/src/RawField.d.ts" <<'STUB'
import type {WGLTexture} from 'autumn-wgl';
import type {TypedArray} from './AutumnTypes';
import type {DomainBufferGrid} from './grids/DomainBuffer';
export abstract class ExpressionScalarField<ArrayType extends TypedArray, GridType extends DomainBufferGrid> {
    abstract readonly dtypes: string[];
    abstract readonly grid: GridType;
    abstract getSamplerIds(): string[];
    abstract getExpression(): string;
    abstract updateTexImageData(
        gl: WebGL2RenderingContext,
        filter: number,
        existing: Map<string, WGLTexture> | null,
    ): Map<string, WGLTexture>;
}
STUB
cat > "$TMP/src/utils.d.ts" <<'STUB'
export function applySamplerCodeScalar(source: string, ids: string[], expression: string, dtypes: string[]): string;
STUB
cat > "$TMP/src/ShaderManager.d.ts" <<'STUB'
import type {WGLBuffer, WGLTexture} from 'autumn-wgl';
import type {RendererData} from './AutumnTypes';
export class StubProgram {
    setUniforms(values: Record<string, number | number[]>): void;
    bindTextures(values: Record<string, WGLTexture>): void;
    draw(): void;
    use(
        attributes: Record<string, WGLBuffer>,
        uniforms: Record<string, number | number[]>,
        textures: Record<string, WGLTexture>,
    ): void;
}
export class ShaderProgramManager {
    constructor(vertex: string, fragment: string, defines: string[]);
    getShaderProgram(gl: WebGL2RenderingContext, shaderData: RendererData['shaderData']): StubProgram;
    getShaderUniforms(data: RendererData): Record<string, number | number[]>;
}
STUB
cat > "$TMP/globals.d.ts" <<'STUB'
declare function require(path: string): string;
STUB
cat > "$TMP/tsconfig.json" <<'STUB'
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "Bundler",
    "lib": ["ES2022", "DOM"],
    "strict": true,
    "noEmit": true,
    "skipLibCheck": false,
    "verbatimModuleSyntax": false,
    "forceConsistentCasingInFileNames": true,
    "useDefineForClassFields": true
  },
  "include": ["src/**/*.ts", "src/**/*.d.ts", "globals.d.ts"]
}
STUB
(cd "$TMP" && tsc --project tsconfig.json --pretty false)
printf 'TypeScript strict integration check passed (tsc %s)\n' "$(tsc --version | awk '{print $2}')"
