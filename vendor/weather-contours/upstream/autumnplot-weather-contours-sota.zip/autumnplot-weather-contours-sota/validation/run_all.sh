#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

./validation/typecheck_ts.sh
python3 validation/test_gpu_math.py
python3 validation/test_worker_math.py
python3 validation/test_band_reference.py
python3 validation/rust_static_check.py
python3 validation/test_integration.py
python3 validation/test_demo_integration.py
python3 validation/compile_shaders.py

if command -v cargo >/dev/null 2>&1; then
  (
    cd rust/weather-contours
    cargo fmt --all -- --check
    cargo clippy --locked --all-targets -- -D warnings
    cargo test --locked
  )
  if rustup target list --installed 2>/dev/null | grep -qx wasm32-unknown-unknown; then
    ./rust/weather-contours/build-wasm.sh
  elif [[ "${REQUIRE_RUST_WASM:-0}" == "1" ]]; then
    echo 'wasm32-unknown-unknown is required but not installed' >&2
    exit 1
  else
    echo 'Rust native checks passed; skipping WASM build because target is not installed.'
  fi
elif [[ "${REQUIRE_RUST:-0}" == "1" ]]; then
  echo 'Rust toolchain is required but unavailable.' >&2
  exit 1
else
  echo 'Rust compile/lint/tests skipped: cargo is unavailable. Static ABI checks did run.'
fi

if [[ "${RUN_BENCH:-0}" == "1" ]]; then
  python3 bench/webgl_benchmark.py
fi
