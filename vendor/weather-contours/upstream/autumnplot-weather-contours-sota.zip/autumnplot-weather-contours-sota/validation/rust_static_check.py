#!/usr/bin/env python3
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUST = ROOT / 'rust' / 'weather-contours' / 'src'


def strip_rust(source: str) -> str:
    # Sufficient for delimiter validation: replace comments and string/char
    # literals with whitespace while preserving newlines.
    source = re.sub(r'/\*.*?\*/', lambda m: '\n' * m.group(0).count('\n'), source, flags=re.S)
    source = re.sub(r'//[^\n]*', '', source)
    source = re.sub(r'r#+".*?"#+', '""', source, flags=re.S)
    source = re.sub(r'"(?:\\.|[^"\\])*"', '""', source, flags=re.S)
    source = re.sub(r"'(?:\\.|[^'\\])'", "''", source, flags=re.S)
    return source


def balanced(path: Path) -> None:
    source = strip_rust(path.read_text())
    pairs = {')': '(', ']': '[', '}': '{'}
    stack: list[tuple[str, int]] = []
    for index, char in enumerate(source):
        if char in '([{':
            stack.append((char, index))
        elif char in pairs:
            assert stack and stack[-1][0] == pairs[char], (path, index, char, stack[-3:])
            stack.pop()
    assert not stack, (path, stack[-5:])


def main() -> None:
    sources = list(RUST.glob('*.rs'))
    assert {path.name for path in sources} == {'lib.rs', 'bands.rs', 'wasm_abi.rs'}
    for path in sources:
        balanced(path)

    combined = '\n'.join(path.read_text() for path in sources)
    assert 'paste_accessor' not in combined
    assert combined.count('visited[index] = true;') == 1
    assert '&output.levels.clone()' not in combined
    assert 'HashMap<VertexKey, u32>' in combined
    assert 'critical_saddle_cells' in combined
    assert 'EdgeRange' in combined and 'asymptotic_q' in combined

    cargo = (ROOT / 'rust' / 'weather-contours' / 'Cargo.toml').read_text()
    assert 'wasm-bindgen' not in cargo and '[dependencies]\n' in cargo
    assert 'crate-type = ["rlib", "cdylib"]' in cargo

    abi = (RUST / 'wasm_abi.rs').read_text()
    rust_exports = set(re.findall(r'\b(wc_[a-z0-9_]+)\b', abi))
    loader = (ROOT / 'autumnplot-src' / 'WeatherContoursWasm.ts').read_text()
    ts_exports = set(re.findall(r'^\s+(wc_[a-z0-9_]+): NumericExport;', loader, flags=re.M))
    missing = ts_exports - rust_exports
    assert not missing, f'TypeScript expects missing Rust exports: {sorted(missing)}'
    assert {'wc_contour_levels', 'wc_isobands', 'wc_alloc_f32', 'wc_free_f32'} <= rust_exports

    assert 'into_boxed_slice()' in abi
    assert 'Box::from_raw(slice_pointer)' in abi
    assert 'Vec::from_raw_parts' not in abi
    assert 'Vec::with_capacity(length)' not in abi.replace(
        '// Using Vec::with_capacity(length) here would be unsound', ''
    )

    worker = (ROOT / 'autumnplot-src' / 'ContourCreator.worker.ts').read_text()
    assert 'loadWeatherContoursWasm' in worker and 'geometry.contourLevels(' in worker
    assert "./WasmInterface" not in worker and 'makeContoursFloat32' not in worker
    assert 'MAX_COMPATIBILITY_LEVELS = 65_536' in worker

    build = (ROOT / 'rust' / 'weather-contours' / 'build-wasm.sh').read_text()
    assert 'cargo build --locked' in build
    assert '$PACKAGE_ROOT/lib' in build and '$PACKAGE_ROOT/public' in build

    print(
        f'Rust structural/ABI validation passed ({len(sources)} modules, '
        f'{len(ts_exports)} loader exports matched)'
    )


if __name__ == '__main__':
    main()
