#!/usr/bin/env python3
from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = '''function makeExistingLayers() { return {layers: []}; }\n\nconst views = {\n    'default': {name: "Existing", makeLayers: makeExistingLayers, maxZoom: 7},\n};\n'''


def run(*args: str, cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, cwd=cwd, text=True, capture_output=True, check=True)


def main() -> None:
    with tempfile.TemporaryDirectory(prefix='autumnplot-demo-') as directory:
        repo = Path(directory)
        (repo / 'public').mkdir()
        target = repo / 'public' / 'main.js'
        target.write_text(MAIN)
        run('git', 'init', '-q', cwd=repo)
        run('git', 'config', 'user.email', 'validation@example.invalid', cwd=repo)
        run('git', 'config', 'user.name', 'Validation', cwd=repo)
        run('git', 'add', '.', cwd=repo)
        run('git', 'commit', '-qm', 'fixture', cwd=repo)

        command = (
            'node', str(ROOT / 'demo' / 'install-current-upstream-demo.mjs'),
            str(repo), '--force',
        )
        first = run(*command, cwd=repo)
        assert 'Installed selectable WeatherContours SOTA demo' in first.stdout
        installed = target.read_text()
        assert installed.count('// WEATHER-CONTOURS-SOTA-DEMO:BEGIN') == 1
        assert installed.count("'weather-contours-sota':") == 1
        assert 'new apgl.WeatherContours' in installed
        run('node', '--check', str(target), cwd=repo)

        second = run(*command, cwd=repo)
        assert 'already installed' in second.stdout
        assert target.read_text() == installed

        reverted = run(
            'node', str(ROOT / 'demo' / 'revert-current-upstream-demo.mjs'),
            str(repo), cwd=repo,
        )
        assert 'Reverted WeatherContours SOTA demo' in reverted.stdout
        assert target.read_text() == MAIN

    print('Pinned AutumnPlot public-demo install/idempotence/revert test passed')


if __name__ == '__main__':
    main()
