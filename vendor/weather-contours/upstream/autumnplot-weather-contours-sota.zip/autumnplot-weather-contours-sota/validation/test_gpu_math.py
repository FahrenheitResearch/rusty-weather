#!/usr/bin/env python3
from __future__ import annotations

import bisect
import math
import random
import struct

DIRECTORY_SIZE = 256


def f32(value: float) -> float:
    return struct.unpack('<f', struct.pack('<f', value))[0]


def next_down_f32(value: float) -> float:
    bits = struct.unpack('<I', struct.pack('<f', f32(value)))[0]
    if math.isnan(value) or value == -math.inf:
        return value
    if value == 0.0:
        bits = 0x80000001
    elif value > 0:
        bits -= 1
    else:
        bits += 1
    return struct.unpack('<f', struct.pack('<I', bits))[0]



def next_up_f32(value: float) -> float:
    bits = struct.unpack('<I', struct.pack('<f', f32(value)))[0]
    if math.isnan(value) or value == math.inf:
        return value
    if value == 0.0:
        bits = 1
    elif value > 0:
        bits += 1
    else:
        bits -= 1
    return struct.unpack('<f', struct.pack('<I', bits))[0]


def exact_regular_layout(levels: list[float]) -> tuple[bool, float]:
    interval = f32(levels[1] - levels[0])
    if not interval > 0:
        return False, interval
    dyadic = False
    for exponent in range(21):
        scale = 2 ** exponent
        scaled = [value * scale for value in [*levels, interval]]
        if all(value.is_integer() and abs(value) <= 2 ** 23 for value in scaled):
            dyadic = True
            break
    if not dyadic:
        return False, interval
    for index, level in enumerate(levels):
        if f32(levels[0] + f32(index * interval)) != level:
            return False, interval
    return True, interval


def regular_boundary(minimum: float, interval: float, index: int) -> float:
    return f32(minimum + f32(index * interval))


def full_regular_upper_bound(value: float, minimum: float, interval: float, count: int) -> int:
    low, high = 0, count
    for _ in range(13):
        if low < high:
            middle = low + (high - low) // 2
            if value < regular_boundary(minimum, interval, middle):
                high = middle
            else:
                low = middle + 1
    return low


def certified_regular_band(value: float, levels: list[float], interval: float) -> tuple[int, bool]:
    band_count = len(levels) - 1
    estimate = math.floor(f32(f32(value - levels[0]) / interval))
    candidate = max(0, min(band_count - 1, estimate))
    lower = regular_boundary(levels[0], interval, candidate)
    if value < lower and candidate > 0:
        candidate -= 1
    elif candidate < band_count - 1 and value >= regular_boundary(levels[0], interval, candidate + 1):
        candidate += 1
    lower = regular_boundary(levels[0], interval, candidate)
    upper_ok = candidate == band_count - 1 or value < regular_boundary(levels[0], interval, candidate + 1)
    if value >= lower and upper_ok:
        return candidate, False
    return max(0, min(band_count - 1, full_regular_upper_bound(value, levels[0], interval, len(levels)) - 1)), True


def validate_regular_fast_path(rng: random.Random) -> tuple[int, int]:
    tested = 0
    fallbacks = 0
    maps: list[list[float]] = []
    for minimum in [-4096.0, -17.0, -1.0, 0.0, 0.125, 17.0, 4096.0, 1_000_000.0]:
        for interval in [0.125, 0.25, 0.5, 1.0, 2.0, 16.0]:
            levels = [f32(minimum + index * interval) for index in range(17)]
            if all(levels[index] > levels[index - 1] for index in range(1, len(levels))):
                regular, _ = exact_regular_layout(levels)
                if regular:
                    maps.append(levels)
    # Include maximum-count integer levels and many randomized integer/dyadic maps.
    maps.append([f32(-2048 + index) for index in range(4096)])
    for _ in range(300):
        exponent = rng.randrange(0, 9)
        interval = 2.0 ** (-exponent)
        minimum = rng.randrange(-(2 ** 20), 2 ** 20) * interval
        count = rng.choice([2, 3, 17, 63, 257, 1024])
        levels = [f32(minimum + index * interval) for index in range(count)]
        regular, _ = exact_regular_layout(levels)
        if regular:
            maps.append(levels)

    for levels in maps:
        regular, interval = exact_regular_layout(levels)
        assert regular
        probes = [levels[0], levels[-1]]
        for level in levels:
            probes.extend([next_down_f32(level), level, next_up_f32(level)])
        for _ in range(200):
            ordinal = rng.randrange(len(levels) - 1)
            probes.append(f32(levels[ordinal] + rng.random() * (levels[ordinal + 1] - levels[ordinal])))
        for value in probes:
            if value < levels[0] or value > levels[-1]:
                continue
            expected = max(0, min(len(levels) - 2, bisect.bisect_right(levels, value) - 1))
            actual, fallback = certified_regular_band(value, levels, interval)
            assert actual == expected, (levels[0], interval, value, expected, actual)
            tested += 1
            fallbacks += int(fallback)
    # Explicit regression: naïve arithmetic misclassifies nextDown(0) here.
    levels = [f32(-1.0 + index) for index in range(17)]
    value = next_down_f32(0.0)
    naive = math.floor(f32(f32(value - levels[0]) / 1.0))
    assert naive == 1
    actual, fallback = certified_regular_band(value, levels, 1.0)
    assert actual == 0 and not fallback
    return tested, fallbacks

def bucket(value: float, minimum: float, maximum: float) -> int:
    numerator = f32(value - minimum)
    denominator = f32(maximum - minimum)
    normalized = max(0.0, min(1.0, f32(numerator / denominator)))
    scaled = f32(normalized * DIRECTORY_SIZE)
    return min(math.floor(scaled), DIRECTORY_SIZE - 1)


def directory(levels: list[float]) -> tuple[list[tuple[int, int]], int]:
    n = len(levels)
    mins = [n] * DIRECTORY_SIZE
    maxs = [-1] * DIRECTORY_SIZE
    for position in range(1, n + 1):
        lower = levels[position - 1]
        upper = max(lower, next_down_f32(levels[position])) if position < n else levels[-1]
        first = bucket(lower, levels[0], levels[-1])
        last = bucket(upper, levels[0], levels[-1])
        if last < first:
            first, last = last, first
        first = max(0, first - 1)
        last = min(DIRECTORY_SIZE - 1, last + 1)
        for b in range(first, last + 1):
            mins[b] = min(mins[b], position)
            maxs[b] = max(maxs[b], position)
    result = []
    max_span = 0
    for b in range(DIRECTORY_SIZE):
        low = 0 if maxs[b] < 0 else mins[b]
        high = n if maxs[b] < 0 else maxs[b]
        result.append((low, high))
        max_span = max(max_span, high - low)
    return result, max_span


def directory_upper_bound(levels: list[float], table: list[tuple[int, int]], value: float) -> int:
    low, high = table[bucket(value, levels[0], levels[-1])]
    for _ in range(13):
        if low < high:
            middle = low + (high - low) // 2
            if value < levels[middle]:
                high = middle
            else:
                low = middle + 1
    return low


def make_unique_f32(values: list[float]) -> list[float]:
    return sorted(set(f32(value) for value in values if math.isfinite(value)))


def validate_levels(levels: list[float], rng: random.Random) -> int:
    table, max_span = directory(levels)
    probes = [levels[0], levels[-1], *levels]
    probes += [next_down_f32(level) for level in levels[1:]]
    probes += [
        f32(levels[0] + (levels[-1] - levels[0]) * rng.random())
        for _ in range(5000)
    ]
    for value in probes:
        if value < levels[0] or value > levels[-1]:
            continue
        expected = bisect.bisect_right(levels, value)
        actual = directory_upper_bound(levels, table, value)
        assert actual == expected, (len(levels), value, expected, actual, table[bucket(value, levels[0], levels[-1])])
    return max_span


def test_alpha_equivalence(rng: random.Random) -> None:
    for _ in range(100_000):
        fill = [rng.random() for _ in range(4)]
        line = [rng.random() for _ in range(4)]
        background = [rng.random() for _ in range(4)]
        fa, la = fill[3], line[3]
        # Fused premultiplied source over background.
        fused_rgb = [
            line[i] * la + fill[i] * fa * (1 - la) + background[i] * (1 - la) * (1 - fa)
            for i in range(3)
        ]
        # Straight-alpha fill, then premultiplied line.
        after_fill = [fill[i] * fa + background[i] * (1 - fa) for i in range(3)]
        split_rgb = [line[i] * la + after_fill[i] * (1 - la) for i in range(3)]
        assert max(abs(a - b) for a, b in zip(fused_rgb, split_rgb)) < 1.0e-12


def main() -> None:
    rng = random.Random(0xC0B4_2026)
    maximum_span = 0

    # Maximum supported boundary count, including exact edge insertions.
    regular = [f32(-2048.0 + index) for index in range(4096)]
    maximum_span = max(maximum_span, validate_levels(regular, rng))

    # Strongly clustered and logarithmic maps stress directory-bin boundaries.
    for count in [2, 3, 17, 63, 257, 1024, 4096]:
        clustered = make_unique_f32([
            math.copysign(abs(rng.gauss(0.0, 1.0)) ** 5, rng.choice([-1.0, 1.0]))
            for _ in range(count * 3)
        ])
        if len(clustered) >= count:
            clustered = clustered[:count]
        if len(clustered) >= 2:
            maximum_span = max(maximum_span, validate_levels(clustered, rng))

        logarithmic = make_unique_f32([
            -10.0 ** (-6 + 12 * index / max(1, count - 1))
            for index in range(count // 2)
        ] + [
            10.0 ** (-6 + 12 * index / max(1, count - 1))
            for index in range(count - count // 2)
        ])
        if len(logarithmic) >= 2:
            maximum_span = max(maximum_span, validate_levels(logarithmic, rng))

    # Twelve iterations are demonstrably insufficient at the supported maximum.
    low, high = 0, 4096
    for _ in range(12):
        middle = low + (high - low) // 2
        high = middle
    assert (low, high) == (0, 1)

    regular_probes, regular_fallbacks = validate_regular_fast_path(rng)
    test_alpha_equivalence(rng)
    print(
        'Exact GPU classifier validation passed '
        f'(4096 boundaries, clustered/log maps, max tested bracket {maximum_span}, '
        f'{regular_probes:,} adversarial regular probes, {regular_fallbacks} cold fallbacks, '
        '100,000 alpha-equivalence cases)'
    )


if __name__ == '__main__':
    main()
