#!/usr/bin/env python3
"""Independent numerical reference for COBRM's cell decomposition and clipping."""
from __future__ import annotations

import bisect
import math
import random
from dataclasses import dataclass


@dataclass(frozen=True)
class V:
    x: float
    y: float
    value: float


def critical_center(sw: float, se: float, ne: float, nw: float) -> tuple[V, bool]:
    b = se - sw
    c = nw - sw
    d = ne - se - nw + sw
    scale = max(abs(sw), abs(se), abs(ne), abs(nw), 1.0)
    if abs(d) > math.ulp(1.0) * 64 * scale:
        u = -c / d
        v = -b / d
        eps = math.ulp(1.0) * 64
        if eps < u < 1 - eps and eps < v < 1 - eps:
            return V(u, v, sw + b * u + c * v + d * u * v), True
    return V(0.5, 0.5, 0.25 * (sw + se + ne + nw)), False


def crossing(a: V, b: V, threshold: float) -> V:
    t = (threshold - a.value) / (b.value - a.value)
    t = max(0.0, min(1.0, t))
    return V(a.x + t * (b.x - a.x), a.y + t * (b.y - a.y), threshold)


def clip(poly: list[V], threshold: float, above: bool) -> list[V]:
    if not poly:
        return []
    inside = (lambda value: value >= threshold) if above else (lambda value: value <= threshold)
    out: list[V] = []
    previous = poly[-1]
    previous_inside = inside(previous.value)
    for current in poly:
        current_inside = inside(current.value)
        if previous_inside and current_inside:
            out.append(current)
        elif previous_inside and not current_inside:
            out.append(crossing(previous, current, threshold))
        elif not previous_inside and current_inside:
            out.append(crossing(previous, current, threshold))
            out.append(current)
        previous = current
        previous_inside = current_inside
    dedup: list[V] = []
    for vertex in out:
        if not dedup or (vertex.x, vertex.y, vertex.value) != (dedup[-1].x, dedup[-1].y, dedup[-1].value):
            dedup.append(vertex)
    if len(dedup) > 1 and dedup[0] == dedup[-1]:
        dedup.pop()
    return dedup


def polygon_area(poly: list[V]) -> float:
    return abs(sum(
        poly[i].x * poly[(i + 1) % len(poly)].y - poly[(i + 1) % len(poly)].x * poly[i].y
        for i in range(len(poly))
    )) * 0.5 if len(poly) >= 3 else 0.0


def triangle_band_area(triangle: list[V], levels: list[float]) -> float:
    minimum = min(v.value for v in triangle)
    maximum = max(v.value for v in triangle)
    if maximum < levels[0] or minimum > levels[-1]:
        return 0.0
    first = min(max(0, bisect.bisect_left(levels, minimum) - 1), len(levels) - 2)
    end = min(bisect.bisect_right(levels, maximum), len(levels) - 1)
    total = 0.0
    for band in range(first, end):
        poly = clip(triangle, levels[band], True)
        poly = clip(poly, levels[band + 1], False)
        total += polygon_area(poly)
    return total


def cell_band_area(values: tuple[float, float, float, float], levels: list[float]) -> tuple[float, bool]:
    sw, se, ne, nw = values
    center, critical = critical_center(sw, se, ne, nw)
    corners = [V(0, 0, sw), V(1, 0, se), V(1, 1, ne), V(0, 1, nw)]
    triangles = [
        [corners[0], corners[1], center],
        [corners[1], corners[2], center],
        [corners[2], corners[3], center],
        [corners[3], corners[0], center],
    ]
    return sum(triangle_band_area(triangle, levels) for triangle in triangles), critical


def main() -> None:
    rng = random.Random(0xB4AD_2026)
    cases = 25_000
    saddles = 0
    maximum_error = 0.0
    for _ in range(cases):
        values = tuple(rng.uniform(-50, 50) for _ in range(4))
        lo = min(values)
        hi = max(values)
        internal = sorted(rng.uniform(lo, hi) for _ in range(rng.randrange(0, 12)))
        levels = [lo, *internal, hi]
        area, critical = cell_band_area(values, levels)
        saddles += int(critical)
        error = abs(area - 1.0)
        maximum_error = max(maximum_error, error)
        assert error < 2.0e-11, (values, levels, area)

    saddle_area, critical = cell_band_area((1.0, -1.0, 1.0, -1.0), [-1.0, 0.0, 1.0])
    assert critical and abs(saddle_area - 1.0) < 1.0e-12

    # If levels span only part of the field, emitted area must remain bounded.
    for _ in range(5000):
        values = tuple(rng.gauss(0, 3) for _ in range(4))
        area, _ = cell_band_area(values, [-1.0, 0.0, 1.0])
        assert -1.0e-12 <= area <= 1.0 + 1.0e-12

    print(
        f'COBRM reference validation passed ({cases:,} full-coverage cells, '
        f'{saddles:,} interior saddles, max area error {maximum_error:.3e}, '
        '5,000 partial-coverage cells)'
    )


if __name__ == '__main__':
    main()
