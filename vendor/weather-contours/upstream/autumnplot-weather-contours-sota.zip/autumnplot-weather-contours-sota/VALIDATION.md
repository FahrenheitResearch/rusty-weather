# Validation Record

## Automated validation executed in the artifact environment

### TypeScript

Command:

```bash
./validation/typecheck_ts.sh
```

Result:

```text
TypeScript strict integration check passed (tsc 5.8.3)
```

The harness provides strict stubs for the AutumnPlot, Comlink, and AutumnWGL interfaces and compiles `WeatherContours.ts`, the raw WASM loader, and the replacement contour worker.

### Exact GPU classifier

Command:

```bash
python3 validation/test_gpu_math.py
```

Result:

```text
Exact GPU classifier validation passed
(4096 boundaries, clustered/log maps, max tested bracket 3382,
301,649 adversarial regular probes, 0 cold fallbacks,
100,000 alpha-equivalence cases)
```

Coverage includes:

- maximum boundary count;
- random clustered and logarithmic maps;
- exact upper-bound comparison against a CPU reference;
- every tested regular boundary plus immediate float32 neighbors;
- the cancellation regression for the float immediately below zero;
- fused line-over-fill versus two-pass blend equivalence.


### OIRT compatibility worker reference

Command:

```bash
python3 validation/test_worker_math.py
```

Result:

```text
OIRT compatibility-worker reference validation passed
(65,536 binary16 patterns, 2,046 NaNs,
20,000 interval cases, 75,703 packed paths)
```

Coverage includes exhaustive binary16-to-float32 widening, randomized regular-level generation, the 65,536-level allocation guard, packed path grouping, and closed-path compatibility duplication. TypeScript compilation separately verifies the production worker source and its AutumnPlot interfaces.

### COBRM independent reference

Command:

```bash
python3 validation/test_band_reference.py
```

Result:

```text
COBRM reference validation passed
(25,000 full-coverage cells, 8,380 interior saddles,
max area error 4.441e-16, 5,000 partial-coverage cells)
```

The reference checks critical-point fan decomposition and clipped-band area conservation independently of the Rust implementation's data structures.

### Rust ABI structural gate

Command:

```bash
python3 validation/rust_static_check.py
```

Result:

```text
Rust structural/ABI validation passed (3 modules, 29 loader exports matched)
```

This checks delimiter structure, required algorithm invariants, dependency-free Cargo configuration, boxed-slice allocation/free symmetry, worker routing away from the old C++ module, multi-target WASM deployment, and exact TypeScript-to-Rust export-name coverage. It is not a substitute for a Rust compiler.

### Integration scripts

Commands:

```bash
python3 validation/test_integration.py
python3 validation/test_demo_integration.py
```

Results:

```text
Pinned integration apply/idempotence/revert test passed
Pinned AutumnPlot public-demo install/idempotence/revert test passed
```

Both use temporary Git repositories and verify restoration of original bytes, including the replaced contour worker. The full exact upstream checkout/build is a separate CI job.

### Real WebGL 2 compiler and AutumnWGL preprocessor

Command:

```bash
python3 validation/compile_shaders.py
```

Result:

```text
Real Chromium WebGL2 compile/link + autumn-wgl uniform check passed
(36 variants × 2 paths; WebGL 2.0 (OpenGL ES 3.0 Chromium); WebKit WebGL)
```

The matrix spans regular, explicit, and mixed level layouts; fill, masked fill, fused lines, and split lines; plus hardware and manual-bilinear field sampling. Each production variant is compiled twice:

1. with the driver's GLSL preprocessor;
2. after emulating AutumnWGL's custom `#ifdef`/`#ifndef` stripping.

The second path also verifies that every declared uniform remains active, because current AutumnWGL treats a null location as an integration failure.

## WebGL benchmark

Command:

```bash
python3 bench/webgl_benchmark.py
```

Configuration:

- scalar texture: 1799×1059;
- viewport: 1024×768;
- 17 boundaries / 16 bands;
- seven rounds;
- 12 frames per round;
- median completed GPU timer-query time.

Recorded SwiftShader medians:

| Path | ms/frame | Comparison |
|---|---:|---:|
| Current-shape GPU fill baseline | 27.293 | baseline |
| Exact GPU fill | 22.841 | 1.19× throughput |
| Favorable legacy GPU-only fill + analytic lines | 41.965 | baseline |
| Exact split fill + lines | 54.159 | 0.77× throughput |
| Exact fused fill + lines | 36.517 | 1.15× throughput |

The benchmark is a microbenchmark, not a claim about a physical GPU. SwiftShader timings vary with host scheduling. The favorable line baseline intentionally omits the current vector-contour extraction and upload pipeline, so it understates the total legacy cost.

Raw samples and renderer metadata are in `bench/webgl-results.json`.

## Rust status

No Rust toolchain was installed in the artifact environment, DNS access for downloading one was unavailable, and no generated WASM is included. The following were therefore **not** executed locally:

- `cargo fmt --check`;
- Clippy;
- `cargo test`;
- native benchmark;
- `wasm32-unknown-unknown` build.

This limitation is explicit. The package includes source tests, a native benchmark example, a locked dependency-free crate, and CI gates that require all of those operations with Rust 1.89.0.

The raw allocator was manually hardened during review: inputs are boxed slices and are reconstructed with their exact lengths, avoiding the unsound assumption that a `Vec::with_capacity(n)` allocation must have capacity exactly `n`.

## CI gates included

`.github/workflows/validate.yml` has three jobs:

1. **core:** deterministic tests, integrations, real Chromium shader validation, WebGL benchmark;
2. **rust-and-wasm:** rustfmt, Clippy with warnings denied, native tests, benchmark-example build, raw WASM build;
3. **pinned-upstream:** exact AutumnPlot checkout, library integration, selectable demo installation, npm-library and webpack builds, raw WASM copies beside all worker deployment targets, and byte-restoring reverts.

CI is provided but was not run from this local artifact directory. A merge decision should require a green run.

## Physical-GPU acceptance pass

Before claiming production performance, run on representative Intel, AMD, NVIDIA, Apple, and mobile GPUs:

```bash
python3 bench/webgl_benchmark.py
```

Then run the selectable map demo and record:

- renderer and browser version;
- fused/split auto choice;
- tuning completion;
- map frame p50/p95 while static and while updating;
- JavaScript submit p50/p95;
- field upload p50/p95;
- visual comparisons at every exact boundary;
- masks, transparency, globe projection, and world copies;
- context-loss behavior.

## Merge gate

A defensible merge gate is:

- green included CI on the candidate commit;
- no visual mismatch in a boundary-neighbor image corpus;
- physical-GPU benchmark results attached for supported hardware;
- exact pinned-upstream demo loaded in Chromium, Firefox, and Safari/WebKit where WebGL 2 is available;
- explicit decision on dropping WebGL 1 for `ContourFill`;
- API review of bounded-only Rust isobands;
- no new Clippy or TypeScript warnings.
