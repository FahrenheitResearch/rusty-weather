# Design: Exact Weather Contours for AutumnPlot

## 1. Design goals

The rewrite is organized around one rule: do not make interactive display pay the cost of vector topology, and do not pretend a display shader is a vector-geometry engine.

The system therefore has two lanes:

1. **GPU display lane** for exact discrete fills and optional solid isolines.
2. **Rust geometry lane** for connected isolines and indexed isoband geometry.

Both lanes consume the same semantic object: an ordered list of finite float32 boundaries. A band ordinal `k` means the bounded interval between boundaries `k` and `k + 1`. Underflow and overflow are represented separately in the GPU palette.

The principal requirements are:

- correct `contourf` behavior, not only lines;
- exact boundary ownership at float32 precision;
- no CPU contour extraction for ordinary interactive fills;
- no floating-point endpoint hashing in vector topology;
- deterministic ambiguous-cell handling;
- packed outputs suitable for WASM transfer;
- current-upstream integration with reversible, pinned transformations;
- performance claims tied to reproducible baselines.

## 2. GPU architecture

### 2.1 Existing AutumnPlot resources are reused

`WeatherContours` obtains domain vertex and texture-coordinate buffers from the existing `DomainBufferGrid`. Scalar textures are created through `ExpressionScalarField.updateTexImageData()`, so raw and computed fields use the same expression injection already used by AutumnPlot fills. The scalar sampler/expression signature is frozen at component construction; `updateField()` accepts new data for that program but rejects a silent change that would require recompiling shaders.

WebGL 2 does not guarantee linear filtering for float32 textures. When `OES_texture_float_linear` is absent, the component uploads source textures with nearest filtering and evaluates four texel-center samples in the fragment shader to reproduce bilinear interpolation. Half-float WebGL 2 sampling continues through the hardware path. The active mode is exposed as `usesManualBilinearFiltering` and participates in the autotune cache key.

No intermediate scalar grid is built for computed fields. The generated fragment shader calls AutumnPlot's injected `get_field_value(v_tex_coord)` expression.

### 2.2 Palette layout

Each color map is uploaded as one nearest-filtered RGBA8 texture:

```text
[underflow, band 0, band 1, ..., band N-1, overflow]
```

Transparent missing underflow or overflow colors are stored as zero-alpha entries. This avoids branches that depend on whether optional colors exist.

### 2.3 Level layouts

A `WeatherContours` component chooses one shader layout for all color maps:

- `REGULAR_LEVELS`: every map passed the conservative exact-regular test;
- `EXPLICIT_LEVELS`: no map passed it;
- `MIXED_LEVELS`: maps differ, so threshold textures exist and a per-map uniform selects the regular estimator when valid.

One layout per component keeps shader variants bounded while retaining the O(1) estimator for mixed masked products where possible.

## 3. Float32-exact band classification

### 3.1 Boundary convention

For a value inside the finite level range, the classifier computes the equivalent of `upper_bound(levels, value) - 1`, clamped to a valid band ordinal. Therefore a value exactly equal to an interior boundary belongs to the band above that boundary. The top boundary belongs to the final finite band; a value strictly greater than it is overflow.

The JavaScript validation first converts all boundaries to float32, then requires:

- at least two boundaries;
- at most 4096;
- every boundary finite;
- strict ordering after float32 conversion;
- a complete positive span that remains finite in float32.

Rejecting an overflowing span is safer than allowing directory normalization to silently produce infinities.

### 3.2 Certified regular classifier

An apparently regular JavaScript level array is not automatically safe for arithmetic classification. The implementation requires a shared power-of-two scale under which all boundaries and the interval become integers no larger than the exact 23-bit float32 integer range. It then verifies every reconstructed boundary:

```text
f32(level_min + f32(index × interval)) == supplied_level[index]
```

At draw time, arithmetic gives a candidate band:

```text
candidate = floor((value - level_min) / interval)
```

That estimate alone is not exact. For example, subtracting a negative minimum can round the float immediately below a boundary onto the boundary. The shader therefore certifies the candidate against the exact reconstructed lower and upper levels, repairs the common one-bin error, and uses a 13-step exact upper-bound search if the bracket still fails.

In 301,649 adversarial probes—including every tested boundary and its immediate float32 neighbors—the certification path produced exact results with zero cold fallbacks.

### 3.3 Exact Ordinal Directory for arbitrary maps

A uniform 256-bin value directory narrows an arbitrary-level upper-bound search. Directory construction does not store an approximate band. It stores a conservative pair of insertion-position bounds.

For every possible upper-bound position, the builder determines the float32 value interval that produces that position, maps both ends through shader-equivalent float32 normalization, expands by one adjacent directory bucket, and marks all covered buckets. The final bucket contains the minimum and maximum insertion position that could map there.

The shader fetches the bracket from an RG16UI texture and performs 13 fixed binary-search iterations over the R32F level texture. Thirteen comparisons cover a half-open interval of width 4096.

This is called the **Exact Ordinal Directory (EOD)**. It is deliberately different from using a low-resolution inverse colormap as the answer: the directory only bounds an exact search.

### 3.4 Missing data and masks

NaN and infinity are discarded. With `cmap_mask`, zero means transparent and values `1..M` select one of `M` maps. Mask validation occurs on construction and update, and the shader uses nearest sampling.

## 4. GPU isolines and pass selection

### 4.1 Screen-space line distance

For a sample value, the shader finds the nearest adjacent boundary. It estimates the value gradient in screen space with:

```glsl
length(vec2(dFdx(value), dFdy(value)))
```

Dividing value distance by this magnitude gives an approximate pixel distance to the isoline. A smooth transition around half the requested width produces antialiasing. Euclidean gradient length avoids the directional width bias of using the L1-style `fwidth` value directly.

Flat or numerically degenerate gradients return no line instead of dividing by near-zero values.

### 4.2 Major boundaries

A boundary is major when its ordinal satisfies the configured modular rule:

```text
(boundary_index - major_offset) mod major_every == 0
```

Major lines have independent color and width. Setting `major_every` to zero disables major styling.

### 4.3 Fused and split rendering

- **Fused:** classify once, shade the band, compute the line, premultiply and compose line-over-fill, then use one framebuffer blend.
- **Split:** use a straight-alpha fill pass and a separate premultiplied line pass.

Neither mode is universally fastest. Fused saves a complete second classification and texture traversal; split has simpler shader programs. `auto` alternates the modes while collecting disjoint GPU timer queries, discards two warm-up samples per mode, compares five-sample medians, and caches the winner by renderer, level layout, mask state, grid size, map shape, and line configuration.

Pending queries are bounded. A disjoint event resets samples. Failure, context loss, missing extension, or a 96-render tuning limit resolves safely to fused or to the best available measurements.

## 5. OIRT connected isolines

### 5.1 Edge ordinal ranges

For sorted levels, all levels crossing one finite grid edge form a contiguous ordinal interval. Each horizontal and vertical edge stores:

```text
first_level, crossing_count, prefix_base
```

A prefix sum over crossing counts gives every crossing a stable integer node ID:

```text
node_id = edge.prefix_base + (level_index - edge.first_level)
```

No interpolated coordinate is used as a topology key.

### 5.2 Cell connectivity

For each finite cell, only levels between the cell minimum and maximum are visited. The marching case connects edge-node IDs. Saddle cases use a bilinear asymptotic quantity rather than a fixed checkerboard split. The adjacency store is fixed-degree: a valid contour crossing has at most two neighbors.

### 5.3 Traversal

1. Traverse all degree-one nodes to emit open paths.
2. Traverse each remaining unvisited degree-two component as a closed cycle.
3. Interpolate coordinates only when writing packed output.

Closed paths carry a flag and do not duplicate their first vertex. This avoids extra coordinates and makes closure explicit.

### 5.4 Compatibility worker

The pinned integration keeps AutumnPlot's `ContourData` API by replacing `ContourCreator.worker.ts`. Float16 storage is widened through a complete 65,536-entry lookup table, OIRT runs through the raw WASM loader, and packed paths are grouped by normalized level. Closed paths duplicate their first point only at this boundary because the legacy return type has no closure flag. A 65,536-level guard bounds accidental compatibility allocations.

`quad_as_tri` is retained in the option type but does not alter extraction; OIRT uses the bilinear asymptotic decision for ambiguous cells. The compatibility path still constructs nested arrays and `RawField` still transforms each point. Direct packed callers avoid those costs.

### 5.5 Complexity

Let `E` be grid edges, `L` requested levels, `A` active cell-level pairs, and `V` emitted crossings. The intended behavior is:

```text
O(E log L + A + V)
```

with contiguous arrays for ranges, adjacency, visitation, and packed output. This removes nested fragment maps, repeated path splicing, and endpoint float hashing from the hot path.

## 6. COBRM indexed isobands

### 6.1 Why a second geometry algorithm exists

Connected boundary paths are insufficient for filled export. Polygonizing independently generated lines introduces containment, hole, clipping, and numerical matching problems. COBRM emits the band mesh directly.

### 6.2 Critical-point fan

For a bilinear cell

```text
f(u,v) = a + b u + c v + d u v
```

an interior critical point exists at:

```text
u* = -c / d
v* = -b / d
```

when `d` is nonzero and both coordinates lie strictly inside the cell. Such a point is used for a four-triangle fan in a saddle cell. Other cells use the bilinear center. The center value is evaluated from the bilinear function.

This makes the decomposition respect the saddle's critical topology instead of selecting connectivity from an arbitrary geometric center.

### 6.3 Band clipping

Each fan triangle is clipped against the lower and upper threshold of every band intersecting its scalar range. The resulting convex polygon is triangulated as a fan.

Vertex identities are keyed by discrete support:

- original grid vertex;
- cell center;
- `(horizontal rail, level ordinal)` crossing;
- `(vertical rail, level ordinal)` crossing;
- `(cell spoke, level ordinal)` crossing.

Adjacent cells share horizontal and vertical rail crossings. Fan triangles inside a cell share spoke crossings. Coordinates are not hash keys.

### 6.4 Output and scope

`PackedBands` contains:

- normalized levels;
- flat XY vertices;
- u32 triangle indices;
- one band ordinal per triangle;
- mesh statistics.

It emits bounded interior bands only. Underflow and overflow do not have a finite polygon without a clipping-domain convention, so the API does not invent one.

The topology is critical-point-aware, while the emitted edges are piecewise linear on the fan. A future exact-geometry lane could represent bilinear hyperbola arcs explicitly, but that would be a different output contract and a poor direct fit for ordinary GPU triangle rendering.

## 7. Raw WASM interface

The crate has no dependencies. A `cdylib` build exports allocation, extraction, packed-array pointer/length accessors, statistics, error code, and handle cleanup.

Inputs use boxed float32 slices. JavaScript performs all allocations before creating a memory view because a later Rust allocation may grow WebAssembly memory and detach an earlier view. Outputs are copied before handles are freed. There are no JavaScript object graphs crossing the ABI.

The build script can place the same module beside `lib/`, `dist/`, and `public/` workers. The default worker URL is relative to `self.location`; `initAutumnPlot({wasm_base_url})` can instead supply a directory or exact module URL.

## 8. Approaches deliberately rejected

- **GPU line-only replacement:** does not solve `contourf`.
- **CPU polygon generation for every interactive frame:** pays topology cost when the user only needs pixels.
- **Low-resolution inverse-colormap answer texture:** fast but not exact for clustered or adversarial levels.
- **Floating endpoint hash maps:** unnecessary topology fragility and allocation overhead.
- **Fixed diagonal split for every saddle:** can choose the wrong component connectivity.
- **Always fused or always split:** hardware-dependent performance makes either universal claim weak.
- **`wasm-pack`-only delivery:** adds a failed tooling dependency to a crate that needs no binding generator.

## 9. Novelty boundary

OIRT, EOD, and COBRM are project names for these implementations. Their components have clear ancestry in marching methods, asymptotic saddle disambiguation, prefix compaction, search directories, and polygon clipping. The combination is designed specifically for structured weather fields and AutumnPlot's execution model. No exhaustive prior-art or patent review was performed.
